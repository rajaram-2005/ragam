import React, { useEffect, useRef, useState } from 'react'
import { api } from '../api.js'
import { Banner, Button, Field } from './ui.jsx'
import ProviderCatalogue from './ProviderCatalogue.jsx'
import KlyvaronTiers from './KlyvaronTiers.jsx'
// `account` decides what this dialog offers. The gateway connection and its key belong to
// the installation, so only the owner account may change them: if the operator enables
// member registration, letting a member re-point the connection or delete the stored key
// would hand that member control of the owner's provider connection. A member still sees the connection and can
// use it, and is told why the controls are disabled rather than finding them inert.
//
// The runtime is a choice of destination, not a setting of the model. Each option is ONLINE
// inference: the request is sent to the endpoint entered here. A local Ollama or llama.cpp
// server is online in that sense, and the dialog says so rather than calling it local.
export const RUNTIME_OPTIONS = Object.freeze([
  { id: 'ollama', label: 'Ollama (on the Core host)', keyRequired: false, credential: 'api_key', placeholder: 'http://<core-host>:11434/v1', hint: 'Ollama\u2019s OpenAI-compatible base. The Core host must list this exact origin in AETHERIS_TRUSTED_ORIGINS. A key is optional.' },
  { id: 'llamacpp', label: 'llama.cpp server (on the Core host)', keyRequired: false, credential: 'api_key', placeholder: 'http://<core-host>:8080/v1', hint: 'Base of a running llama-server. The Core host must list this exact origin in AETHERIS_TRUSTED_ORIGINS. A key is needed only if the server was started with --api-key.' },
])
// A connection may be one of the built-in local runtimes, a catalogue vendor whose wire this build speaks,
// or a named custom endpoint. Pending adapters are never offered: the server refuses them, and an
// option that the server refuses is a promise this dialog cannot keep.
const CUSTOM_OPTION = { id: 'custom', label: 'Custom OpenAI-compatible endpoint', wire: 'openai_chat', credential: 'api_key' }
// A wire decides what the base URL points at and what the credential is. The server returns both
// on every catalogue entry and every saved connection; this table only supplies the sentence that
// tells a person what to paste, and a missing entry falls back to the generic OpenAI-compatible one.
const ENDPOINT_FOR_WIRE = Object.freeze({
  azure_openai: { placeholder: 'https://<resource>.openai.azure.com', hint: 'The resource endpoint from the Azure portal. This client adds /openai/v1. The selected id is sent as `model`, so it must be the deployment name; the data-plane model list does not enumerate deployments.' },
  openai_chat: { placeholder: 'https://api.openai.com/v1', hint: 'OpenAI Chat Completions API base, including /v1. This contract adapter does not claim Responses-only features.' },
  baidu_qianfan_chat: { placeholder: 'https://qianfan.baidubce.com/v2', hint: 'Baidu Qianfan OpenAI-compatible API. Model discovery filters the documented catalogue to chat models not marked offline. API use may incur charges.' },
  alibaba_model_studio_chat: { placeholder: 'https://dashscope-intl.aliyuncs.com', hint: 'Alibaba Model Studio Singapore endpoint by default. The adapter lists text-input/text-output catalog entries and calls the OpenAI-compatible Chat endpoint; region, workspace, model access and API keys vary. Replace the host with the exact region/workspace endpoint documented for your account. API use may incur charges.' },
  openrouter_chat: { placeholder: 'https://openrouter.ai/api/v1', hint: 'OpenRouter routed API base, including /api/v1. Per-model capabilities are provider/model-dependent.' },
  mistral_chat: { placeholder: 'https://api.mistral.ai/v1', hint: 'Mistral API base, including /v1.' },
  deepseek_chat: { placeholder: 'https://api.deepseek.com', hint: 'DeepSeek API root. The adapter adds /models and /chat/completions.' },
  cerebras_chat: { placeholder: 'https://api.cerebras.ai/v1', hint: 'Cerebras Inference API base; model discovery and Chat Completions are fixture-tested against the documented routes. Check current access terms; API use may incur charges.' },
  deepinfra_chat: { placeholder: 'https://api.deepinfra.com/v1/openai', hint: 'DeepInfra OpenAI-compatible API base. Model discovery filters the documented catalog to chat-tagged models; API use may incur charges.' },
  minimax_chat: { placeholder: 'https://api.minimax.io/v1', hint: 'MiniMax international OpenAI-compatible API. For a China-region account, use the API host documented for that account (api.minimaxi.com). API use may incur charges.' },
  siliconflow_chat: { placeholder: 'https://api.siliconflow.com/v1', hint: 'SiliconFlow international OpenAI-compatible API. Model discovery requests only chat models; China-region accounts may require the documented api.siliconflow.cn host. API use may incur charges.' },
  moonshot_chat: { placeholder: 'https://api.moonshot.ai/v1', hint: 'Moonshot AI Kimi API base. This adapter uses the documented OpenAI-compatible Chat Completions and model-list endpoints. API use may incur charges; check the API platform terms.' },
  sarvam_chat: { placeholder: 'https://api.sarvam.ai/v2', hint: 'Sarvam Open-Source Models API. Model discovery is deployment-specific. This adapter sends the API key in the documented api-subscription-key header; the docs also list bearer auth as an alternative, which this adapter does not use. Usage may be billed.' },
  groq_chat: { placeholder: 'https://api.groq.com/openai/v1', hint: 'Groq OpenAI-compatible API base, including /openai/v1.' },
  together_chat: { placeholder: 'https://api.together.xyz/v1', hint: 'Together API base, including /v1.' },
  fireworks_chat: { placeholder: 'https://api.fireworks.ai', hint: 'Fireworks API root. Inference and account-scoped model listing use different documented API paths.' },
  xai_responses: { placeholder: 'https://api.x.ai/v1', hint: 'xAI API base, including /v1. Uses the native Responses API.' },
  perplexity_router: { placeholder: 'https://api.perplexity.ai', hint: 'Perplexity API root. Model listing uses /v1/models; chat uses /router/v1/chat/completions.' },
  novita_chat: { placeholder: 'https://api.novita.ai/openai/v1', hint: 'Novita OpenAI-compatible API base, including /openai/v1.' },
  sambanova_chat: { placeholder: 'https://api.sambanova.ai/v1', hint: 'SambaNova Cloud API base, including /v1. Dedicated SambaStack endpoints are operator supplied.' },
  huggingface_chat: { placeholder: 'https://router.huggingface.co/v1', hint: 'Hugging Face Inference Providers router. The token needs the Inference Providers permission.' },
  vllm_chat: { placeholder: 'http://<vllm-host>:8000/v1', hint: 'Optional vLLM server. The Core host must trust this exact origin; model-specific parser settings govern features.' },
  localai_chat: { placeholder: 'http://<localai-host>:8080/v1', hint: 'Optional LocalAI server. The Core host must trust this exact origin; backend and parser determine features.' },
  gcp_vertex: { placeholder: 'https://us-central1-aiplatform.googleapis.com', hint: 'The regional Vertex AI endpoint. The service-account JSON names the project; the region comes from this host.' },
  aws_bedrock: { placeholder: 'https://bedrock-runtime.us-east-1.amazonaws.com', hint: 'The Bedrock runtime endpoint for your credential\u2019s region. Requests are signed with SigV4.' },
  cohere_chat: { placeholder: 'https://api.cohere.com', hint: 'Cohere\u2019s API host. This client adds /v2/chat and /v1/models.' },
  openai_images: { placeholder: 'https://api.openai.com/v1', hint: 'OpenAI Images API base, including /v1. The Image area generates through this connection; it is not used for chat.' },
  gemini_veo: { placeholder: 'https://generativelanguage.googleapis.com/v1beta', hint: 'Gemini API base, including /v1beta. The Video area starts a Veo long-running operation through this connection; it is not used for chat or images.' },
  anthropic_messages: { placeholder: 'https://api.anthropic.com/v1', hint: 'Anthropic\u2019s API base, including /v1.' },
  gemini_generate: { placeholder: 'https://generativelanguage.googleapis.com/v1beta', hint: 'The Gemini API base, including /v1beta.' },
  stability_images: { placeholder: 'https://api.stability.ai', hint: 'Stability API base (the adapter adds /v2beta/stable-image/generate/...). The key is sent as a Bearer token.' },
  recraft_images: { placeholder: 'https://external.api.recraft.ai/v1', hint: 'Recraft API base, including /v1. This adapter asks for inline PNG bytes (b64_json), never a download URL.' },
  ideogram_images: { placeholder: 'https://api.ideogram.ai', hint: 'Ideogram API base (the adapter adds /v2/image/generate/{model}). The key is sent as the Api-Key header.' },
  bfl_images: { placeholder: 'https://api.bfl.ai', hint: 'Black Forest Labs API base. The adapter polls the provider-supplied polling_url and downloads the signed sample without the key.' },
  fal_images: { placeholder: 'https://queue.fal.run', hint: 'fal.ai queue base. Model ids include their owner path (fal-ai/flux/dev); the key is sent as Authorization: Key.' },
  fal_video: { placeholder: 'https://queue.fal.run', hint: 'fal.ai queue base. The same queue contract as images; the clip URL is downloaded without the key.' },
  replicate_images: { placeholder: 'https://api.replicate.com/v1', hint: 'Replicate API base, including /v1. Model ids are owner/name; polling uses the prediction own urls.get.' },
  replicate_video: { placeholder: 'https://api.replicate.com/v1', hint: 'Replicate API base, including /v1. Video models are polled to a signed output URL, then validated as MP4.' },
  runway_video: { placeholder: 'https://api.dev.runwayml.com', hint: 'Runway API base. Every request carries the documented X-Runway-Version header; cancellation is a DELETE on the task.' },
  luma_video: { placeholder: 'https://api.lumalabs.ai/dream-machine/v1', hint: 'Luma Dream Machine API base, including /v1. Generations are polled until completed, then the clip is downloaded without the key.' },
  firefly_images: { placeholder: 'https://firefly-api.adobe.io', hint: 'Adobe Firefly API base. The credential is a client id and secret; a short-lived IMS token is exchanged and cached in memory only.' },
  comfyui_images: { placeholder: 'http://comfyui:8188', hint: 'ComfyUI must be reachable from the Core container. This hostname works only when a ComfyUI service named comfyui shares its private Docker network; the default Ragam Compose stack does not start one. Do not use localhost for a Windows host service or expose unauthenticated ComfyUI to the LAN/Internet. No credential or model is bundled. Trust only the exact private origin in AETHERIS_TRUSTED_ORIGINS.' },
})
const endpointFor = (wire) => ENDPOINT_FOR_WIRE[wire] ?? {
  placeholder: 'https://api.example.com/v1',
  hint: 'This endpoint\u2019s base URL, including /v1 if it needs it. Its key is sent only to this connection.',
}
const CREDENTIAL_FOR_KIND = Object.freeze({
  none: { label: 'No credential', hint: 'This local service does not use an API credential.' },
  api_key: { label: 'API key', hint: 'Stored encrypted on the server; never saved in browser storage or returned by the API.' },
  service_account: { label: 'Service-account JSON', hint: 'Paste the downloaded service-account key file. It is validated and compacted on the server and encrypted at rest; the private key is never returned by the API.' },
  aws_credentials: { label: 'IAM credential JSON', hint: '{"accessKeyId":"\u2026","secretAccessKey":"\u2026"} with optional "sessionToken" and "region". The secret signs requests and is never returned by the API.' },
  // Firefly has no single API key. The client id is public; the secret is the credential.
  client_credentials: { label: 'Adobe client JSON', hint: '{"clientId":"\u2026","clientSecret":"\u2026"} from the Adobe Developer Console. Both are sealed server-side; the secret is never returned.' },
})
const credentialFor = (kind) => CREDENTIAL_FOR_KIND[kind] ?? CREDENTIAL_FOR_KIND.api_key
const gibibytes = (value) => Number.isSafeInteger(value) && value >= 0 ? `${(value / 1024 ** 3).toFixed(1)} GiB` : 'not reported'
// A saved connection that is not one of the built-in local runtimes still needs a label and a key rule on
// screen. Deriving both from the record the server returned is the only way this stays true when a
// catalogue entry is added: the client must not keep a second copy of the catalogue's facts.
const connectionOption = (connection) => ({
  id: connection.id,
  label: connection.label,
  keyRequired: connection.keyRequired,
  wire: connection.wire ?? null,
  credential: connection.credential ?? 'api_key',
  ...endpointFor(connection.wire),
})

// `provider` lets a caller render the dialog with a state already loaded — the server-render test
// does this because effects do not run there, and the browser effect below still refreshes it from
// the server so a stale prop cannot become stale state.
export default function ProviderSettings({ account, onClose, onChanged, provider: loaded = null }) {
  const owner = account?.role === 'owner'
  const dialog = useRef(null)
  const [provider, setProvider] = useState(loaded), [kind, setKind] = useState(loaded?.kind ?? 'ollama'), [url, setUrl] = useState(loaded?.baseUrl ?? ''), [key, setKey] = useState('')
  const [busy, setBusy] = useState(false), [error, setError] = useState(null), [notice, setNotice] = useState('')
  const [hardwareInfo, setHardwareInfo] = useState(null), [hardwareError, setHardwareError] = useState(null), [hardwareBusy, setHardwareBusy] = useState(false)
  // Non-fatal: the catalogue is information, and failing to load it must not stop somebody from
  // configuring or testing their connection.
  const [catalog, setCatalog] = useState(null)
  const [addKind, setAddKind] = useState('')
  const [addUrl, setAddUrl] = useState(''), [addKey, setAddKey] = useState(''), [addAccountId, setAddAccountId] = useState('')
  const connections = provider?.connections ?? []
  // The saved connection, when it is for the runtime on screen. Test and remove act on that.
  const saved = connections.find((connection) => connection.id === kind) ?? null
  const selectedEvidence = saved?.modelDetails?.find((entry) => entry.id === saved?.selectedModel) ?? null
  const selectedVerification = saved?.verified?.[saved?.selectedModel] ?? null
  const runtimeOptions = [...RUNTIME_OPTIONS, ...connections
    .filter((connection) => !RUNTIME_OPTIONS.some((option) => option.id === connection.id))
    .map(connectionOption)]
    .map((option) => ({
      ...option,
      recommended: Boolean(catalog?.providers?.find((entry) => entry.id === option.id)?.recommended),
    }))
  // An id this dialog has never heard of must not be displayed as a different connection. If the server returned
  // a record for it, that record supplies the label and the key rule; only a totally unknown id
  // falls back, and the select will then show the first option while the state keeps the real id —
  // which the server, not this component, validates.
  const runtime = runtimeOptions.find((option) => option.id === kind)
    ?? (saved ? connectionOption(saved) : RUNTIME_OPTIONS[0])
  const savedIds = new Set(connections.map((connection) => connection.id))
  const addOptions = [
    ...(catalog?.providers ?? [])
      // Every catalogue entry this build can actually drive: a native wire or the
      // OpenAI-compatible transport. `pending` is excluded because the server refuses it.
      .filter((entry) => entry.status !== 'pending' && entry.wire !== null)
      .map((entry) => ({
        id: entry.id,
        label: `${entry.recommended ? 'Recommended · ' : ''}${entry.label}${entry.integrationType === 'gateway-routed' ? ' (gateway-routed API)' : entry.integrationType === 'openai-compatible' ? ' (OpenAI-compatible API)' : entry.integrationType === 'native-vendor' ? ' (native API)' : ''}`,
        recommended: Boolean(entry.recommended),
        wire: entry.wire,
        integrationType: entry.integrationType,
        credential: entry.credential ?? 'api_key',
        ...endpointFor(entry.wire),
      })),
    CUSTOM_OPTION,
  ].filter((option) => !savedIds.has(option.id))
    .sort((a, b) => Number(Boolean(b.recommended)) - Number(Boolean(a.recommended)) || a.label.localeCompare(b.label))
  // The form always submits an option it actually offers, including after the one that was
  // selected has just been saved and therefore left the list.
  const nextAddKind = addOptions.some((option) => option.id === addKind) ? addKind : (addOptions[0]?.id ?? '')
  const nextAdd = addOptions.find((option) => option.id === nextAddKind) ?? CUSTOM_OPTION
  const addCredential = credentialFor(nextAdd.credential)
  useEffect(() => {
    dialog.current?.showModal()
    api.provider().then((s) => {
      setProvider(s); setKind(s.kind ?? 'ollama'); setUrl(s.baseUrl)
      const activeConnection = s.connections?.find((connection) => connection.id === s.kind)
      setAddAccountId(activeConnection?.options?.accountId ?? s.options?.accountId ?? '')
    }).catch(setError)
    api.catalog().then(setCatalog).catch(() => setCatalog(null))
    return () => { dialog.current?.close() }
  }, [])
  const act = async (action) => {
    setBusy(true); setError(null); setNotice(''); setHardwareInfo(null); setHardwareError(null)
    try {
      const result = await action(); setProvider(result); setKind(result.kind ?? kind); setUrl(result.baseUrl); setKey(''); await onChanged?.()
      return result
    } catch (e) { setError(e); return null } finally { setBusy(false) }
  }
  const inspectComfyHardware = async (connectionId = kind) => {
    setHardwareBusy(true); setHardwareError(null)
    try { setHardwareInfo(await api.providerHardware(connectionId)) } catch (e) { setHardwareError(e) } finally { setHardwareBusy(false) }
  }
  const chooseRuntime = (id) => {
    setKind(id); setKey(''); setError(null); setNotice(''); setHardwareInfo(null); setHardwareError(null)
    // A different runtime is a different recipient, so its endpoint is entered afresh, never copied from the old one.
    const saved = provider?.connections?.find((connection) => connection.id === id)
    setUrl(saved?.baseUrl ?? (provider && provider.kind === id ? provider.baseUrl : ''))
    setAddAccountId(saved?.options?.accountId ?? '')
  }
  return <dialog className="provider-dialog" ref={dialog} onCancel={(e) => { e.preventDefault(); if (!busy) onClose() }} aria-labelledby="provider-settings-title">
    <div className="row between"><h2 id="provider-settings-title">Provider Settings</h2><Button disabled={busy} onClick={onClose}>Close</Button></div>
    <p>Connect cloud APIs (OpenAI/ChatGPT, Anthropic/Claude, Google Gemini and others) or an operator-run local service. “Recommended” marks major model providers and API platforms plus selected self-hosted runtimes for Local-only use; it is not a live check or a guarantee of quality, reliability, capability, or price. Chat, Image and Video use separate provider connections; each request goes to the selected connection with no automatic fallback. API access and charges are controlled by the provider; a ChatGPT or Claude consumer subscription should not be assumed to include API usage. Local Ollama, llama.cpp and ComfyUI endpoints must be reachable from Core and their exact origins listed in AETHERIS_TRUSTED_ORIGINS. Ragam does not install local services or model weights.</p>
    {owner ? null : <Banner tone="info" title="Read-only for this account"><p>Only the owner account of this installation can change its gateway connection or key. You can still choose a model and chat through the connection that is configured.</p></Banner>}
    {error ? <Banner tone="bad" title={error.message} /> : null}
    {notice ? <Banner tone="info" title={notice} /> : null}
    <form onSubmit={async (e) => { e.preventDefault(); if (await act(() => api.saveProvider(kind, { baseUrl: url, ...(key ? { apiKey: key } : {}), ...(kind === 'fireworks' ? { options: { accountId: addAccountId } } : {}) }))) setNotice('Connection saved. Test it to fetch models; no prompt is sent by that test.') }}>
      <Field label="Connection" hint="Which saved connection this form edits. Saving activates it; the other connections and their keys are kept.">
        <select aria-label="Connection" className="select" value={kind} onChange={(e) => chooseRuntime(e.target.value)} disabled={busy || !provider || !owner}>
          {runtimeOptions.map((r) => <option key={r.id} value={r.id}>{r.recommended ? `${r.label} · Recommended` : r.label}</option>)}
        </select>
      </Field>
      <Field label={`${runtime.label} API base URL`} hint={runtime.hint}><input autoFocus className="input" type="url" required value={url} placeholder={runtime.placeholder} onChange={(e) => setUrl(e.target.value)} disabled={busy || !provider || !owner} /></Field>
      {kind === 'fireworks' ? <Field label="Fireworks account ID" hint="Required to retrieve your account-scoped model list. Changing this account ID requires supplying the API key again because the destination changes.">
        <input className="input" type="text" required maxLength={128} pattern="[A-Za-z0-9][A-Za-z0-9._-]{0,127}" value={addAccountId} onChange={(e) => setAddAccountId(e.target.value)} disabled={busy || !provider || !owner} />
      </Field> : null}
      {runtime.credential === 'none' ? <p className="small">{credentialFor(runtime.credential).hint}</p> : <Field
        label={`${credentialFor(runtime.credential).label}${runtime.keyRequired ? '' : ' (optional)'}`}
        hint={saved?.keyConfigured
          ? 'A credential is stored securely on the server. Leave blank to keep it for the same runtime and endpoint.'
          : credentialFor(runtime.credential).hint}
      >
        {runtime.credential === 'api_key'
          ? <input className="input" type="password" autoComplete="new-password" value={key} maxLength={8192} onChange={(e) => setKey(e.target.value)} disabled={busy || !provider || !owner} />
          : <textarea className="textarea" autoComplete="off" spellCheck={false} rows={5} value={key} maxLength={16384} onChange={(e) => setKey(e.target.value)} disabled={busy || !provider || !owner} />}
      </Field>}
      <Button type="submit" variant="primary" busy={busy} disabled={!provider || !url || !owner}>Save connection</Button>
    </form>
    <div className="row" style={{ marginTop: 16 }}>
      <Button busy={busy} disabled={!owner || !saved?.configured || url !== saved?.baseUrl || Boolean(key) || (kind === 'fireworks' && addAccountId !== saved?.options?.accountId)} onClick={async () => {
        const s = await act(() => api.testProvider(kind))
        if (s) {
          setNotice(`Connection checked: ${s.models.length} listed models. Inference and modality support are not yet verified.`)
          if (kind === 'comfyui') await inspectComfyHardware(kind)
        }
      }}>Test connection & refresh models</Button>
      <Button variant="danger" disabled={busy || !owner || !saved} onClick={async () => { if (window.confirm('Remove the connection and any stored key? Your conversations are kept.')) { if (await act(() => api.removeProvider(kind))) setNotice('Connection and stored credential removed.') } }}>Remove connection</Button>
    </div>
    {runtime.wire === 'comfyui_images' ? <section className="provider-hardware" aria-label="ComfyUI hardware report">
      <div className="row between">
        <strong>ComfyUI hardware and checkpoints</strong>
        <Button busy={hardwareBusy} disabled={!owner || !saved?.configured || busy} onClick={() => inspectComfyHardware(kind)}>{hardwareInfo ? 'Refresh hardware report' : 'Detect hardware'}</Button>
      </div>
      <p className="small">After testing the connection, Ragam reads ComfyUI’s own device report. This works even when Core runs in Docker and cannot inspect the Windows host directly.</p>
      {hardwareError ? <Banner tone="warn" title="Hardware report unavailable"><p>{hardwareError.message}</p></Banner> : null}
      {hardwareInfo ? <>
        {hardwareInfo.devices.length
          ? <ul className="small">{hardwareInfo.devices.map((device) => <li key={`${device.index}-${device.name ?? 'device'}`}>
              {device.name ?? `Device ${device.index + 1}`} · {device.backend ?? 'backend not reported'} · VRAM {gibibytes(device.vramTotalBytes)} total, {gibibytes(device.vramFreeBytes)} free at detection
            </li>)}</ul>
          : <p className="small">ComfyUI reported no accelerator devices. This does not prove that the service is CPU-only.</p>}
        <p className="small"><strong>Installed checkpoints:</strong> {saved?.models?.length
          ? `${saved.models.slice(0, 10).join(', ')}${saved.models.length > 10 ? `, and ${saved.models.length - 10} more (available in the Image model list)` : ''}`
          : 'none listed; use Test connection & refresh models to discover them.'}</p>
        <p className="small">This report does not qualify a checkpoint’s hardware compatibility or a Klyvaron tier. Ragam does not choose, download or silently substitute a model.</p>
      </> : null}
    </section> : null}
    {selectedEvidence ? <p className="small" aria-label="Selected model capability evidence">
      Catalogue evidence for <strong>{selectedEvidence.name}</strong>: input {selectedEvidence.capabilities.input.join(', ')}, output {selectedEvidence.capabilities.output.join(', ')}
      {selectedEvidence.capabilities.contextTokens ? `, context window ${selectedEvidence.capabilities.contextTokens.toLocaleString()} tokens` : ''}.
      Streaming: {selectedEvidence.capabilities.streaming}; tools and structured output: not exposed by RAGAM Chat.
      {selectedVerification ? ` A text inference succeeded at ${selectedVerification}; this does not qualify streaming or other capabilities.` : ' No successful text inference has been recorded for this model yet.'}
    </p> : null}
    <p className="small">Model selection lives in Chat. Model-list success is not inference verification. No automatic fallback. Remote requests may incur provider charges; this catalogue does not certify free tiers or quotas. Self-hosted inference avoids a vendor API bill but still uses your hardware, electricity and appropriately licensed weights. Image and Video require separate qualified adapters.</p>
    {provider ? <details className="connections" style={{ marginTop: 20 }} open={(provider.connections?.length ?? 0) > 1}>
      <summary>Saved connections ({provider.connections?.length ?? 0})</summary>
      <p className="small">Each connection has its own encrypted credential. Activating one changes where the next request goes; it does not overwrite the others.</p>
      <ul className="small" aria-label="Saved connections">
        {(provider.connections ?? []).map((connection) => <li key={connection.id}>
          <strong>{connection.label}</strong> — {connection.configured ? (connection.baseUrl || 'configured') : 'not configured'}
          {connection.id === provider.active
            ? <strong> · active</strong>
            : <Button disabled={busy || !owner} onClick={async () => { if (await act(() => api.activateProvider(connection.id))) setNotice(`${connection.label} is now the active connection.`) }}>Use</Button>}
          <Button variant="danger" disabled={busy || !owner} onClick={async () => {
            if (window.confirm(`Remove the ${connection.label} connection and its stored key? Other connections are kept.`)) {
              if (await act(() => api.removeProvider(connection.id))) setNotice(`${connection.label} removed.`)
            }
          }}>Remove</Button>
        </li>)}
      </ul>
      {addOptions.length ? <form onSubmit={async (e) => {
        e.preventDefault()
        if (!nextAddKind) return
        const result = await act(() => api.saveProvider(nextAddKind, {
          baseUrl: addUrl,
          ...(addKey ? { apiKey: addKey } : {}),
          ...(nextAddKind === 'fireworks' ? { options: { accountId: addAccountId } } : {}),
        }))
        if (result) { setAddKey(''); setAddUrl(''); setAddAccountId(''); setNotice('Connection saved and made active. Test it to fetch models; no prompt is sent by that test.') }
      }}>
        <Field label="Add a connection" hint="A catalogue provider whose wire format this build implements, or a custom endpoint. Providers with pending adapters are not listed.">
          <select aria-label="Add a connection" className="select" value={nextAddKind} onChange={(e) => setAddKind(e.target.value)} disabled={busy || !owner}>
            {addOptions.map((option) => <option key={option.id} value={option.id}>{option.label}</option>)}
          </select>
        </Field>
        <Field label="API base URL" hint={`${nextAdd.hint ?? 'Including /v1 if the endpoint needs it.'} Must be public HTTPS unless the operator trusts this exact origin.`}>
          <input className="input" type="url" required value={addUrl} placeholder={nextAdd.placeholder ?? 'https://api.example.com/v1'} onChange={(e) => setAddUrl(e.target.value)} disabled={busy || !owner} />
        </Field>
        {nextAddKind === 'fireworks' ? <Field label="Fireworks account ID" hint="Required for the account-scoped model catalogue. This is configuration metadata, not a credential.">
          <input className="input" type="text" required maxLength={128} pattern="[A-Za-z0-9][A-Za-z0-9._-]{0,127}" value={addAccountId} onChange={(e) => setAddAccountId(e.target.value)} disabled={busy || !owner} />
        </Field> : null}
        {nextAdd.credential === 'none' ? <p className="small">{addCredential.hint}</p> : <Field label={addCredential.label} hint={`${addCredential.hint} Leave blank only for endpoints that need none.`}>
          {nextAdd.credential === 'api_key'
            ? <input className="input" type="password" autoComplete="new-password" value={addKey} maxLength={8192} onChange={(e) => setAddKey(e.target.value)} disabled={busy || !owner} />
            : <textarea className="textarea" autoComplete="off" spellCheck={false} rows={5} value={addKey} maxLength={16384} onChange={(e) => setAddKey(e.target.value)} disabled={busy || !owner} />}
        </Field>}
        <Button type="submit" disabled={busy || !owner || !addUrl}>Save and use</Button>
      </form> : null}
    </details> : null}
    <KlyvaronTiers providers={provider} owner={owner} onChanged={onChanged} />
    <ProviderCatalogue catalog={catalog} />
  </dialog>
}
