# Phase 2 — online-only product increment

Date: 2026-10-14. This supersedes the earlier offline-first product direction.

**Historical snapshot, updated 2026-11-04:** this document records the 2026-10-14 increment, not the entire current UI. LiteLLM support described below has since been removed from the catalogue, UI, backend and current setup docs; do not follow it as a supported deployment path. The provider framework later added native chat, image and video adapters and several saved connections from a 39-entry catalogue; see [27-provider-framework.md](./27-provider-framework.md). The current app also has an explicit user-computer training/adaptation workflow in Chat, owner-managed MCP Streamable HTTP connections, and the Ragam HTTP plugin contract. The standard end-user Docker deployment now opens directly into a localhost-only single-user workspace with no email or account flow; its security and provider setup are in [22-self-hosted-deployment.md](./22-self-hosted-deployment.md). Direct-Core account-mode details below are retained for development and regression coverage. See [28-user-managed-servers.md](./28-user-managed-servers.md) for the current server workflows. Historical statements below about training and remote plugins/MCP are superseded.

## Agreed scope and delivered change

The user selected **five areas with simplified Chat**; the first iteration used a LiteLLM gateway, which has since been removed.
The active `npm run core` entry now loads `online/app.mjs`, not the legacy offline-first application.

- **Chat, Image, Video, Plugins, MCP** remain the only primary areas. Provider Settings is a dialog reached from the sidebar and Chat.
- At the 2026-10-14 snapshot there was no local/hybrid inference mode, local runtime startup, model downloads, Klyvaron tier/hardware panel, training panel, benchmark panel, God Core dashboard, or local inference fallback. The later Chat training/adaptation workflow is documented in [28-user-managed-servers.md](./28-user-managed-servers.md).
- At this historical snapshot, authenticated Provider Settings saved one OpenAI-compatible gateway endpoint or an Ollama/llama.cpp server. The current Provider Settings and supported integrations are documented in [docs/04 §7](./04-setup.md#7-connecting-chat-image-and-video-providers).
- A visible model picker saves an exact model ID. Unknown/unavailable selections fail rather than silently choosing another model. Model listings are labelled unverified; successful text inference is recorded separately. A gateway alias may itself route upstream; Aetheris does not attest to the gateway's internal routing policy.
- Real OpenAI-compatible `/chat/completions` transport with SSE, cancellation, total body-inclusive timeout, response/request limits, no redirects, no retries, and at most two concurrent chat requests per installation.
- Conversation history, optional approved memory and text-file knowledge remain. Files are limited to supported plain-text formats up to 1 MiB in the UI; no PDF/Office parsing. Context is sent only when selected for the request. Sensitive data needs explicit per-request authorization; credential-shaped content is redacted. Classification covers the entire assembled request and cannot be lowered by a caller's `public` label.
- At the 2026-10-14 snapshot, Plugins/MCP retained reviewed read-only built-ins and arbitrary installs, trust-key modifications, external MCP registration and agent-driven tool execution were disabled. This historical limitation is superseded by the owner-managed protocols in [28-user-managed-servers.md](./28-user-managed-servers.md); downloaded code remains disabled.

**Not delivered on 2026-10-14:** real online Image/Video generation adapters, direct native provider integrations (Ollama's `/api/chat` and llama.cpp's native protocols are not used online; both runtimes are reached over `/v1`), cloud deployment, durable autonomous tasks, or a qualified Sparsiz training loop. Image/Video clearly stated that their adapters were not connected; no synthetic output was substituted. On 2026-10-17 the image and video adapters landed (docs/27); cloud deployment and a qualified Sparsiz loop remain undone, and no live vendor call has been made.

## Run and connect

Node >=22.5 and the existing Web dependencies are sufficient for the online product; Python, NumPy, Fabric and model weights are not required to run it.

```bash
npm run core
# another terminal
npm run web
```

Core binds `0.0.0.0:8790`; Web uses relative `/api` requests through the Vite proxy. The proxy preserves the request Host so the same-origin check works behind the Arena preview. For HTTPS preview/production, secure cookies remain enabled. For **HTTP-only local development**, explicitly use:

```bash
AETHERIS_COOKIE_SECURE=false npm run core
```

**Sign-in is an account, not a token.** The operator token file this increment originally created (`.aetheris-data/online/access-token`) has been **removed**, together with its `{ token }` login route: there is one way in. The operator must configure `AETHERIS_OWNER_EMAIL` before the first account can be created; the matching address becomes owner. Member sign-up is closed by default and requires an explicit operator opt-in. Accounts, scrypt password hashes, sessions, per-account data isolation and the host-delivered password-reset flow are specified in [docs/20](20-accounts-and-sign-in.md). Sign-in still creates an HttpOnly, eight-hour cookie whose `SameSite` is `Strict` by default (`AETHERIS_COOKIE_SAMESITE=none` opts in for an installation embedded in another site, and requires secure cookies), sessions are still bounded and revoked on restart, and sign-out still invalidates the current session.

The original increment supported only LiteLLM, Ollama and llama.cpp; that workflow is retained as historical record, not a current setup guide. For current browser-based setup across the catalogue—including OpenAI/ChatGPT, Anthropic/Claude, Google Gemini, image services and video services—follow [docs/04 §7](./04-setup.md#7-connecting-chat-image-and-video-providers) and the live [provider matrix](./27-provider-framework.md). Saving a connection does not itself send a prompt; model-list success is not live inference verification. Inference is an explicit user action, uses the selected provider/model without fallback, and may incur that provider's charges.

No provider credentials have been supplied or real external inference performed in this increment. This Arena sandbox's outbound destinations are restricted to GitHub/npm/PyPI infrastructure; arbitrary remote provider connectivity is not available for live qualification here. Run/deploy on a host with authorized network access to qualify actual inference. Local fixtures used in tests are explicitly synthetic, never exposed as user models in the preview.

## Active configuration

Export environment variables into the process; the new entry does not load legacy `.env` files automatically.

| Variable | Default | Meaning |
|---|---|---|
| `AETHERIS_CORE_HOST` | `0.0.0.0` | Bind address, not authorization |
| `AETHERIS_CORE_PORT` | `8790` | API port |
| `AETHERIS_ONLINE_DATA_DIR` | `.aetheris-data/online` | Separate settings, accounts, history, memory and knowledge directory |
| `AETHERIS_COOKIE_SECURE` | `true` | Set `false` only for deliberate HTTP local development |
| `AETHERIS_COOKIE_SAMESITE` | `strict` | `none` when the web app is served inside another site's iframe; requires secure cookies |
| `AETHERIS_OWNER_EMAIL` | unset | Required first-owner email; unset means self-hosted registration fails closed |
| `AETHERIS_ALLOW_ACCOUNT_REGISTRATION` | `false` | Opt in to member sign-ups after owner bootstrap |
| `AETHERIS_MAX_ACCOUNTS` | `1` self-hosted | Account cap; increase explicitly before enabling members |
| `AETHERIS_PRINT_RESET_CODES` | `false` | Also print a password-reset code on the Core console |
| `AETHERIS_TRUSTED_ORIGINS` | empty | Comma-separated exact origins trusted for a private provider endpoint or local Ollama / llama.cpp server |
| `AETHERIS_CORE_URL` | proxy default | Web server's backend target, never a browser-facing localhost URL |
| `WEB_PORT` | `5173` | Web server port |

Without an explicitly trusted internal origin, private provider-endpoint configuration requires HTTPS and forbids IP-literal private destinations. A local Ollama or llama.cpp server is HTTP on loopback, so it needs its exact origin listed the same way. DNS addresses are filtered at connection lookup, blocking private/link-local destinations; the connected address is chosen from that filtered resolution rather than validating once and resolving again. Redirects are never followed. An internal gateway requires an exact operator allowlist entry; it remains classified as **online inference** because it may forward upstream. This does not claim OS-wide network isolation or attest to a gateway's behavior.

The provider key is encrypted with AES-256-GCM in `provider.json`, using the server-owned `master.key`. Both files and the token are protected by filesystem permissions; plaintext keys are never returned by settings APIs, stored in browser storage, or written to the audit ledger. Someone who obtains both ciphertext and the master key can decrypt it. This is not protection against a compromised server/OS; production should use managed secret storage and appropriate backups/access controls. Deletion removes the active stored key, not historical filesystem backups.

## Security boundary and remaining limitations

This installation has **accounts**. The self-hosted Core requires a configured first-owner email, then closes registration by default; member registration is an explicit operator choice. Conversation, memory and file knowledge are per account (separate databases, not filters); the gateway connection and its key belong to the installation and can be changed only by its owner account. All settings, conversation, memory, knowledge and tool APIs require authentication. Mutations require a same-origin request and non-simple request header; no permissive CORS is emitted. Only health, sign-in status, registration, sign-in and password reset are public. No client-provided principal grants access to another identity. Sign-in is rate-limited and locks an account after repeated failures; account count, session count, request sizes, provider responses and inference concurrency are bounded. See [docs/20](20-accounts-and-sign-in.md) for the full account model and for what password reset without a mail transport does and does not protect against.

Provider credentials remain server-side, but inference data necessarily leaves the deployment when sent. The UI explicitly identifies the selected provider; upstream disclosure, budget enforcement, retention and training policies must be checked with that provider. No free-access, privacy, quota or price guarantee is inferred from a model list. Prompt injection is not solved by classification: external context remains untrusted, and model outputs do not automatically execute tools.

History is saved for completed turns. Incomplete/failed generations retain the draft and visible partial text but do not become saved assistant turns. Existing offline-era data is preserved separately; there is no automatic migration or upload. Local storage of history/context is not offline model inference.

## Validation and preservation

- Full verification: **567 Core + 92 Web + 575 Fabric = 1,234 tests**, followed by production build. The runtime change (Ollama and llama.cpp on the online entry) added 10 Core and 1 Web test; the family development plan added 8 Core tests. The increment before them was 549 + 91 + 575 = 1,215. (This increment delivered 528 + 76 + 575 = 1,179; the accounts and sign-in change in [docs/20](20-accounts-and-sign-in.md) added 21 Core and 15 Web tests.)
- Core adds **19 online-specific tests** for authentication, CSRF, secret storage, model switching/persistence, no fallback, data consent, classification, body deadlines, provider errors, SSE completion, context/history, reviewed tools, and removed routes.
- Web's superseded offline-control/research-panel assertions were replaced with current online UI assertions; remaining component/API/render regressions remain. A new provider-settings render test verifies key input and connection controls.
- Existing legacy Core and Fabric suites are retained. Their passing tests do **not** mean their capabilities are in the online product. Counts include retained research/library coverage.
- SSR render tests passed. A separate Happy DOM event-flow check exercised owner sign-in → settings save → metadata refresh → exact model selection → streamed chat → sign-out against an isolated synthetic gateway. This is DOM simulation, not real-browser or real-provider qualification. Its test-only dependency was installed outside the repository; no production dependency changed.
- Production-preview HTTP checks passed for compiled assets, Host/Origin forwarding, unauthenticated 401 responses, secure sign-in cookies, online-only readiness, settings access and sign-out. The old offline Core and standalone Fabric preview processes were stopped.
- Prior audit evidence is historical and left unchanged. Local/research modules and data are preserved; `legacy-server.mjs` retains the prior entry point and is not an active import. The superseded UI copies under `apps/web/legacy/` were **deleted on 2026-10-17**: nothing imported them, they were tested by nothing, and every component they held has a current replacement in `apps/web/src/areas/`. Do not deploy the legacy API as an authenticated online service.
- No additional production dependency, model installation, training, paid inference, commit or push was performed.

The historical next-increment plan to qualify LiteLLM is superseded: that integration is not supported. Image and video adapters have since been implemented; see the current catalogue and status in [docs/27](./27-provider-framework.md). Professional/industrial or autonomous capabilities remain outside this delivered scope.
