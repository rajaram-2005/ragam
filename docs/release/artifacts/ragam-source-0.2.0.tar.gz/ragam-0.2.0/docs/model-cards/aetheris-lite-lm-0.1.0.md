# Model card — Aetheris Lite LM 0.1.0

> **Archive notice:** this record is not release evidence. No matching weight payload is present in the current checkout; the active Klyvaron processor uses no model weights.
| | |
|---|---|
| **Identifier** | `aetheris-lite-lm@0.1.0` |
| **Family** | `aetheris-lite` |
| **Status** | `not_released` — archived metadata; payload absent from current checkout |
| **Licence** | MIT — first-party weights. No third-party weights are involved. |
| **Parameters** | 359,136 |
| **Base checkpoint** | **none** — trained from random initialisation |
| **Quantization** | none (float32) |
| **Context** | 128 characters |
| **Weights digest** | `82392ef8907455e56e1cee56bf4a074cb9337dc38f79775859b67efa5b822e94` |
| **Config digest** | `d70bbe7780fd296ff28f47e66ab811ac0fffa1c4418954aa2b2c8eab421e2cdb` |
| **Dataset digest** | `c357293317e781f5d97dcf409146090e02517221108c7b9f8cac21832427c8dd` |
| **Vocabulary digest** | `ac62fb43d7c5d40ca5f838d0f1bcf2550c0d9bb944feece074bd2b9ff1b611c8` |
| **Code revision** | `8108d3098d575ca333ca86348fac2567a6364837` |
| **Seeds** | model `0`, data `0`, split `20251012` |
| **Artifact** | `aetheris-lite-lm-82392ef89074.npz`, 1,444,942 bytes — **not in this repository** |
| **Machine-readable card** | [`aetheris-lite-lm-0.1.0.json`](./aetheris-lite-lm-0.1.0.json) |

> **The weights are not in this repository, by policy.** `.gitignore` excludes
> `artifacts/` and every weight format: Aetheris Lite checkpoints are produced by
> `services/fabric` and referenced by digest, never redistributed through Git.

## What this model is

A **character-level decoder-only language model**, trained from random initialisation
on this repository's own text. It predicts the next character given up to 128
characters of context.

It is the first language model in this project that actually exists. Every previous
route to one was blocked: `huggingface.co` and `download.pytorch.org` are unreachable,
`llama-cpp-python` publishes no manylinux x86_64 wheel for any version, and there is
no `.gguf` or `.safetensors` anywhere on the host. Those obstacles apply to *adapting
someone else's* checkpoint. Training from nothing needs a corpus and compute, and
both were already here.

Implementation: `services/fabric/fabric/lm/` — **pure NumPy**, no PyTorch, no GPU, no
network. Every gradient is derived by hand and checked against a central finite
difference.

## Intended use

**Demonstrating that the training pipeline works end to end on conventional
hardware.** Data validation, a leak-proof corpus split, a hand-derived backward pass,
an optimiser, held-out evaluation against computed baselines, a versioned card and a
release gate that can refuse — all of it runs, reproducibly, with no external
dependency.

## Out of scope

- **Not a chat assistant.** It does not follow instructions and has no safety
  behaviour. It is reachable from `/api/chat`, where an unpinned request is refused with
  `model_not_instruction_tuned` (501) and a pinned request returns a continuation
  labelled as one; serving it as an assistant would misrepresent it. (This sentence was
  corrected — see [Corrections](#corrections).)
- **Not a general-purpose model.** It has no world knowledge beyond 1.38 MB of
  repository text.
- **Not compared to any pretrained model.** No such comparison was possible, and none
  is claimed anywhere.

## Evaluation

Held-out perplexity on a **file-disjoint** validation split — no document contributes
to both sides — against three baselines computed from the **same training statistics**
and scored on the **same 165,120 held-out tokens**.

| | Perplexity | Bits/char |
|---|---|---|
| `uniform` (`ln 143`) | 143.0000 | 7.1599 |
| `unigram` (training frequencies) | 35.2895 | 5.1414 |
| `bigram` (`P(next\|prev)`, training adjacencies) | 15.9109 | 3.9917 |
| **Aetheris Lite LM** | **4.4033** | **2.1386** |

**Verdict: beats the strongest baseline.** `perplexityVsBigram` = **0.276748**, i.e.
the model's perplexity is 27.7% of the bigram's — **3.61× better** than the best
non-neural baseline. That ratio, not the raw perplexity, is what the release gate
requires to be ≤ 1.0.

The baselines are why this number means anything. A perplexity on its own depends on
the vocabulary, the corpus and the tokenisation; `4.40` would be neither good nor bad
without the bigram's `15.91` next to it, measured identically.

Other recorded metrics:

| Metric | Value |
|---|---|
| Training loss | 4.8380 → **1.2551** (improvement 3.582929, gate requires ≥ 1.0) |
| Validation unknown-character rate | **0.000497** (gate requires ≤ 0.02) |
| Wall time | 2,220.146 s (37 minutes, 2 CPU cores) |
| Peak memory | 157.8 MB |
| Tokens seen in training | 2048 × 2600 = 5,324,800 |

### Sample (greedy, temperature 0)

```
server the control and the control limits in detail. Sentence 3 describes the
contactor and thermal limits in detail. Se
```

At temperature 0.8 with top-k 40 it is noticeably less coherent, as expected from a
model this size. Both samples are reproduced exactly by the recorded seed.

## Limitations

Recorded on the card itself, generated by `model_limitations()` so they cannot be
forgotten when a card is produced:

- trained from random initialisation; not derived from any pretrained base model
- character-level base model: it predicts the next character of repository text and
  follows no instructions (359,136 parameters, vocabulary of 143)
- output quality is low: this demonstrates the pipeline, not a usable assistant
- reachable from `/api/chat`, where an unpinned request is refused with
  model_not_instruction_tuned (501): it continues text and does not answer questions, and
  presenting it as an assistant would misrepresent it
- no comparison against any pretrained model was performed, and none is claimed

### Corrections

This card is an artifact of record: it is corrected in place only where a statement about
the code was **false**, never where a number was measured, and every correction is
recorded here with what it replaced.

| | |
|---|---|
| **Corrected** | 2026-10-13 |
| **Field** | the `/api/chat` limitation above, in the card JSON and twice in this document |
| **Was** | "deliberately **not** wired into `/api/chat`" |
| **Now** | "reachable from `/api/chat`, where an unpinned request is refused with `model_not_instruction_tuned` (501)" |
| **Why** | the model became installable and routable when the model library landed, and `/api/chat` has refused it with 501 ever since. The old sentence described the opposite behaviour, and a limitation that describes the wrong behaviour is worse than none: it reads as the reason the behaviour is safe |
| **Measured values changed** | **none** — no perplexity, baseline, digest, parameter count or timing was touched, and `card.py` now generates the corrected sentence so a regenerated card matches this one |

Additionally, on the evaluation provenance:

- the corpus is this repository, so the model is trained on the documentation that
  describes it; that is harmless for a pipeline demonstration and should not be
  mistaken for a general-purpose corpus
- evaluated only on in-distribution held-out text, on the same distributions as
  training
- the window is non-overlapping with stride equal to the context length, which is a
  convention, not the only valid choice of evaluation protocol

## Reproducibility

```bash
npm run lm:train
# then
cd services/fabric
python scripts/lm_release.py --report artifacts/aetheris-lite-lm-82392ef89074.report.json --version 0.1.0
```

The same command produces a **bit-identical** artifact.
`tests/test_lm_train.py::test_the_same_run_twice_produces_the_same_artifact` asserts
that on the weight bytes rather than on the loss, and a companion test asserts a
different model seed produces *different* weights — because reproducibility would be
meaningless if the seed did nothing.

## A bug this model found before it was trained

The numeric gradient check failed on its first run, and reported exactly one line:

```
pos: exceeds tolerance by 1.611e-01 at index 37
     (numeric 1.69456020e-01, analytic 8.39019590e-03)
```

The positional-embedding gradient scattered using a `(T, B)` layout while the hidden
state is `(B, T)`, so every position received another position's gradient. No other
test in this repository would have caught it, and a training run would have looked
merely *worse than expected* rather than wrong. Both the fix and a negative control
(the bug reintroduced) are in `tests/test_lm_model.py`.

## Licence and provenance

MIT, consistent with the rest of this repository. Trained entirely on text already in
this repository, so no third-party corpus licence is implicated. Dependency licences
are unchanged from [`../../third-party/NOTICES.md`](../../third-party/NOTICES.md):
the training code uses NumPy and the Python standard library, nothing else.
