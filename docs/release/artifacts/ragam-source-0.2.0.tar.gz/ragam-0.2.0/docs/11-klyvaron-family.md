# The Klyvaron family, and the six levels of learning

> **Model archive notice:** model-training, weight, evaluation and release statements below describe historical experiments or plans only. Matching payloads are absent from this checkout; these records do not establish any current model release. Active Klyvaron uses deterministic model-independent processing, with Lite/Pro/Max as resource/workflow profiles.

> **Active product: online-only (Phase 2).** [Current setup, features and limitations](19-online-only-phase-2.md) supersede the offline-first product instructions below. Legacy local/research code remains for reference and regression tests; it is not loaded by `npm run core`. Suite totals include retained legacy coverage.

Two things that are easy to claim and hard to make true: that a platform has its own
models, and that it learns. This document records what exists for each, and — more
usefully — the mechanism that stops the claim drifting away from the fact.

Everything here is checkable from the repository. Where a count or a digest appears,
it is read from the artifact of record rather than copied from a summary.

---

The controlling local/hybrid/online and hardware-admission requirements are in
[13 — Hardware execution policy](./13-hardware-execution-policy.md). Lite is
CPU-first; Pro is GPU-qualified; Max requires the highest measured compatibility
profile. A device-class label alone never establishes readiness.

CPU deployment now also supports [evaluated int8 candidates](./14-cpu-int8-inference.md).
The released float32 artifact and its capability limits are unchanged; a conversion
is not automatically granted a family release label.

## 1. The three tiers

| Tier | Hardware | Status | Capabilities available | Backing artifact |
|---|---|---|---|---|
| **Klyvaron Lite** | CPU-only computers and supported phones | **Partial** | 2 of 13 | `aetheris-lite-lm-0.1.1` |
| **Klyvaron Pro** | GPU-qualified laptops and desktops (CPU execution supported) | **Partial** | 10 of 15 | `klyvaron-pro-lm-0.1.0`, `klyvaron-pro-image-0.1.0`, `klyvaron-pro-video-0.1.0`, `klyvaron-pro-voice-0.1.0` |
| **Klyvaron Max** | Qualified high-performance GPU computers (CPU execution supported) | **Partial** | 10 of 14 | `klyvaron-max-lm-0.1.0`, `klyvaron-max-image-0.1.0`, `klyvaron-max-video-0.1.0`, `klyvaron-max-voice-0.1.0` |

The two capabilities that were added to each tier are the ones this family exists for: knowing what is current (`trend.awareness`) and understanding what the user expressed across a session (`affect.history`). They are defined, refused and gated — see [22 — The family's purpose](22-klyvaron-differentiation.md) — and they are `unavailable` on every tier, because a mechanism is not a model artifact. They are also **parts of the model** now: `age_buckets` and the `verdict_head` for the present, `state_emb` and the `state_head` for the person, trained in the same loss as next-token prediction ([24 §6](24-own-models.md)), with a measured prototype and no artifact yet.

The status column is a value in `services/core/src/klyvaron/tiers.mjs`, not prose. Pro
and Max are recorded as **unbuilt** rather than omitted, because an omitted capability
and a capability that does not exist are indistinguishable in a listing — and a listing
is exactly where overclaiming starts.

### 1.1 What Klyvaron Lite actually is

A 359,616-parameter character-level language model trained from random initialisation on
this repository's own text, on two CPU cores, in about 34 minutes. Its measurements come
from a committed run record and model card:

| Measure | Value |
|---|---|
| Validation perplexity | 4.8932 |
| Bits per character | 2.2908 |
| Best of three computed baselines | bigram, 15.7588 |
| Ratio to that baseline | 0.310505 |
| Weights digest | `53ae59b2a777be9d22f1f04b6cbc94aee3dad6144ac40e4e25c12f900164b60c` |

It **supersedes `aetheris-lite-lm@0.1.0`** — 359,136 parameters, perplexity 4.4033 against
the bigram's 15.9109, ratio 0.276748, digest `82392ef8…`. That artifact is kept as a
published record rather than withdrawn: its card, its figures and its digest stand. It is
superseded because a released artifact should be one somebody else can check, and its
corpus cannot be re-derived — its revision reads `8108d30…-dirty`, and the gitignored files
it read are gone. The two perplexities are not comparable with each other and neither is
offered as better: the same fixed token budget was spent on corpora of different sizes (the
superseded one is 1,431,417 bytes; the released one is 2,646,300).

The two capabilities it backs are `text.completion` and `text.extract`. **It does not
chat.** The artifact format, the JavaScript runtime, the on-device library and the
provider are implemented and tested, so the model genuinely runs behind the chat
route — as a completion model: an unpinned chat request is refused with
`model_not_instruction_tuned` (501) and this limitation list, and pinning it by id
returns a continuation labelled as one. Presenting it as an assistant would be a
fiction: its output is not fluent and no instruction tuning has been done. The
capability record for `chat` is `unavailable` with that reason attached, and
`services/core/test/klyvaron.test.mjs` asserts the reason stays there.

The table above is the released record, and its artifact was trained at a revision whose
corpus **rebuilds byte for byte** — that is the property the superseded artifact lacks. An
earlier, independent run of the same configuration is committed as
[`experiments/lm-verification-run-67cdd58.json`](./experiments/lm-verification-run-67cdd58.json):
359,520 parameters, perplexity 5.3585 against the bigram's 16.7151 (ratio 0.320578),
gate verdict **RELEASED**, then installed into the on-device library and served over
`/api/chat` as a labelled continuation. It is a verification model, not a version bump:
the corpus is this repository, the repository moved, and the two numbers are not
comparable with each other.

That run's corpus turned out to include this project's own build products, because
`artifacts/` was missing from the directories discovery skips — so a model was reading the
previous model's report as training text. Fixed, and the run repeated on the tree at
`8d9cdf8`; **that repeat produced the released artifact**, and its record is
[`experiments/lm-verification-run-8d9cdf8.json`](./experiments/lm-verification-run-8d9cdf8.json):
359,616 parameters, perplexity 4.8932 against the bigram's 15.7588 (ratio 0.310505), gate
verdict **RELEASED**, installed through `scripts/klyvaron.mjs` and served over `/api/chat`
the same way. The two runs are not comparable with each other or with the superseded
artifact, because each spent the same fixed token budget on a corpus of a different size
with a different vocabulary. What the sequence demonstrates is the pipeline and a
corrected methodology, not progress: the version numbers describe which corpus a model was
trained on, not which model is better.

That distinction is enforced rather than described. A tier label is a **lookup by artifact
id and version** in the backing records (`tierClaimForArtifact`), never a value a manifest
declares about itself: the second artifact is recorded in the tier record as
`status: 'not_a_release'` next to the released one, so neither can be mistaken for the
other, and an artifact that declares a tier nothing backs is loaded and reported with
`tier: null`, no `tier:<name>` tag and no place in the table above. `klyvaron-app.test.mjs`
installs an artifact declaring `tier: 'pro'` and asserts exactly that.

Its limitations are part of the record, not a footnote, and one of them is load-bearing:
**Lite meets the storage target and no capability target.** It is smaller than the 1.5 GB
per-model budget because it is tiny, not because it is efficient. The validator refuses a
backing record with an empty limitations list, on the grounds that a record with no
limitations reads as having none, which is a claim in itself.

### 1.2 Storage: the 5 GB mobile budget

`services/core/src/storage/budget.mjs` accounts for the managed mobile footprint against
the directive's numbers — **5 GB total, strictly below**, with a 500 MB reserve, a 200 MB
app-package target and a 1.5 GB per-primary-model target.

Three decisions are worth stating, because each is a place the accounting could have been
wrong while looking right:

- **It measures.** No parameter count is multiplied by an assumed bytes-per-parameter.
  `measure()` walks the directory and sums `stat.size` over the real files. An estimate is
  fine for planning and useless for a limit, because the failure mode is a device that
  runs out of space while the accounting says it has not. The test proves the difference
  by replacing measurement with an estimate and watching seven tests fail.
- **Deletion is unreachable, not forbidden.** `clean()` iterates only the regenerable
  categories. A protected category raises an error rather than being filtered out, so a
  mistaken caller finds out instead of believing it succeeded. "Never silently delete
  user-owned data" is therefore a property of the code path rather than a rule someone
  has to remember.
- **Refusal is advice, not action.** When a download does not fit, the decision names what
  could be cleared and leaves it to the user. A model download never makes room by
  deleting something the user owns.

Symlinks are counted as their own size and never followed, so a link cannot make the
footprint look larger or smaller than it is.

### 1.3 The mechanism that makes relabelling impossible

The directive's hardest constraint on models is §5A: *"Do not present an unchanged
third-party model as an independently pretrained Klyvaron foundation model."*

Documented rules of this kind are followed until they are inconvenient. So there is no
`tier:` field to set on a model descriptor. A tier label is a **lookup**:

```
tierClaimFor(modelId) -> tier id, or null
```

It returns a tier only when the model id *is* the artifact named in a backing record for a
capability that tier actually provides. A rebranded third-party model, a made-up product
name, and a version that does not exist all return `null` — the label does not appear,
because no string matches. Tested with all three cases.

The family is validated **at startup**. `AetherisOmniApp`'s constructor builds the family
report and throws with the violation list if it is invalid, so a record that claims a
capability nothing backs stops the process instead of reaching a user. By the time a
request arrives, the check has already run.

The validator rejects, among others:

| Refused | Why it matters |
|---|---|
| `available` with no backing artifact | "A tier label is not evidence." |
| A non-`from_scratch` provenance with no base model named | Relabelling a fine-tuned model is the easiest overclaim, and a licence defect |
| `available` with no measurements | A capability record with no numbers is an assertion |
| `available` with no stated limitations | no limitations reads as having none |
| `unbuilt` with an available capability | A tier cannot be less built than its capabilities |
| `available`/`partial` with nothing available | A status can drift from its content |

All six are tested by constructing the offending record and asserting the validator
refuses it. When this validator was first written it caught two violations in the
author's own data — Pro and Max carried comparative descriptions — and the fix was to
make tiers declare `status` + `statusNote`, so the report cannot present an unbuilt tier
as a product.

The report is served on `GET /api/models` as `family`, alongside the routable models.
They answer different questions: `models` is what can serve a request now, `family` is
what Aetheris has built and what backs each claim. It lives there rather than in a
separate area because the model control a user actually sees is in Chat.

### 1.4 Provenance and licence

| Artifact | Provenance | Licence | Base model |
|---|---|---|---|
| `aetheris-lite-lm-0.1.0` | `from_scratch` | MIT (this repository) | none — random initialisation |

No third-party weights are redistributed, and none are present in this repository. The
weights are gitignored by policy and referenced by digest. What this means for
redistribution is in [`03-status.md`](03-status.md) §7 and [`05-security.md`](05-security.md).

---

### 1.5 The development plan

Pro and Max are unbuilt, and Lite is partial. "Develop all three" is only checkable if each tier
has written, testable requirements, so `services/core/src/klyvaron/plan.mjs` derives one for
each tier from its record in `tiers.mjs`. It asks the same seven questions of every tier:

| Gate | Met when |
|---|---|
| Artifact | a model artifact backs at least one capability |
| Provenance | every backing names its provenance and licence |
| Measurements | every available capability has measurements and limitations |
| Chat | an instruction-tuned artifact backs `chat` |
| Capability coverage | every capability the directive names is available |
| Storage target | the primary artifact fits the 1.5 GB mobile budget (mobile tiers only) |
| Hardware qualification | the record shows qualification on the target hardware class |
| Differentiation stance | the family records that it does not compete, and what comparisons it allows instead |
| Trend awareness | an artifact backs `trend.awareness`, with dated-and-sourced held-out scores |
| Affect history | an artifact backs `affect.history`, evaluated on abstention and consent as well as accuracy |
| Modality separation | image and video each have an artifact of their own; a text artifact is never relabelled |
| Own weights | an artifact of this family was trained from random initialisation here and released with a model card; a composed tier can never satisfy it |
| Accelerated runtime | a confirmed accelerator has been measured running the tier |

A gate is derived, never declared. A capability counts only when it is `available` **and** backed,
so a bare `available` label leaves the gates open, exactly as the validator refuses it.
Hardware qualification is open for every tier, because the record has no qualification field at
all. Tier targeting is not evidence of eligibility, and the plan says so rather than leaving the gate
silently open.

```
node services/core/scripts/klyvaron.mjs plan
```

At this commit Lite meets six of thirteen gates: it has an artifact, provenance and measurements,
it fits the storage target, the stance is recorded, and its weights are this family's own — trained
from random initialisation and released with a card. It stays open on chat, on coverage (2 of 13
capabilities), on hardware, on both differentiators and on modality separation. Pro and Max meet
only the stance gate, which needs no artifact because it is a recorded decision rather than a
capability. Both are **this family's own models**, presets of `aetheris-core-v1` trained from random
initialisation, and `own_weights` stays open until weights exist and are released
([24](24-own-models.md)). The composed path — a pinned third-party base under the tier's name — was
considered and refused, and the refusal is a checked rule rather than a paragraph
([23](23-training-free-tiers.md)).

A **second artifact of this family exists**: `klyvaron-mini-lm@0.1.0`, the `mini` preset of the same
`aetheris-core-v1` architecture — **1,421,952 parameters**, trained from random initialisation on
this host on the assembled corpus (this repository's own text plus the licence-checked public sources
in [24 §4](24-own-models.md)), with the evaluation held out **by source** rather than by document:
two whole Python projects, 1,907,072 characters the model never trained on, **perplexity 4.7342
against a bigram baseline of 15.8644**. It took 8,456 s on two cores, and the release gate recorded
**one soft failure — the wall-clock target of 3,600 s — rather than waiving it**. `mini` carries no
tier label: it is the size this machine can train in a single sitting of a few hours, and what it is
for is making the pipeline real — corpus, tokenizer, trainer, release gate and card — rather than
described. It does not move Pro or Max, which stay unbuilt with the steps that need compute
this host does not have. Its differentiator parts are off, because labelling a general corpus with
evidence ages and expressed states is a mechanism that does not exist yet; the parts are
implemented and separately measured ([24 §7](24-own-models.md)). Nothing here trains a model: building Pro or Max needs the corpus,
the accelerated trainer backend and the compute that [24](24-own-models.md) lists as open. Lite chat
needs an instruction-tuned model, which is a training task with its own measured release gate. The
plan is the list of what must be true first.

The path to a Pro or Max training run is written down in [21 — Remote training](21-remote-training.md):
remote compute only, a pinned third-party base, checkpoints on persistent storage and an acceptance gate.
A first LoRA smoke run on Kaggle, on synthetic data, is written and waiting to be run. That pipeline has not yet been run on a GPU, and no Pro or Max artifact exists.

## 2. The six levels of learning

The directive requires these to be formal levels rather than a synonym for conversation
history. The distinction that makes them levels is **what survives a session boundary and
what has to be verified before it does.**

| Level | What is learned | Persists? | Verified before use? | Status |
|---|---|---|---|---|
| **L1** Contextual adaptation | The current conversation's context | No — session only | n/a, nothing is stored | **Implemented and tested** |
| **L2** User-approved memory | Facts the user explicitly asked to keep | Yes, inspectable | User approval is the gate | **Implemented and tested** |
| **L3** Procedural skills | How to perform a recurring task | Yes, as versioned documents | Recorded checks that all passed | **Implemented and tested** |
| **L4** Strategy across tasks | Which approach works, generally | Yes, as regression cases | A validated failure must join the suite | **Partial** — failure recurrence is implemented and the cross-task transfer test has now been run over eight seeds, which found no lesson to transfer; nothing selects a strategy from experience at run time yet |
| **L5** Model adaptation | Changed weights | Yes, as artifacts | Held-out evaluation, and the release gate | **Partial** — SFT, preference and distillation paths exist; stages 4–6 are blocked here |
| **L6** Verified release improvement | A newer artifact replacing an older one | Yes, with rollback | Data manifest, digest, benchmarks, regression + safety checks | **Implemented and tested** |

### 2.1 The central rule

> Learn from experience, verify the lesson, test its generality, then reuse it safely.

Each level is the previous one plus a stronger form of verification. L1 verifies nothing
because it stores nothing. L3 will not promote a skill without recorded checks. L4 will not
add a failure to the permanent suite until it is *validated* rather than merely observed.
L6 will not promote a release at all without a data manifest, base checkpoint, config, code
revision, artifact checksum, benchmarks and a retained known-good baseline.

The distance between the levels is the point. Collapsing them is how "the system learns"
becomes a claim with nothing behind it.

### 2.2 L3 in detail — procedural skills

`services/core/src/skills/` implements the level the directive describes as
experience-driven skill improvement. The governing text is §6C, and its last paragraph —
*"Do not silently rewrite core system instructions, grant new permissions or install
arbitrary code because an agent believes it has learned something"* — is a structural
problem, not a prompt-engineering one. A rule that says "do not do X" can be argued with;
a rule that makes X unreachable cannot.

So the dangerous operations are **unreachable rather than forbidden**:

| Invariant | Enforced by |
|---|---|
| **I1** There is no delete | The registry has no delete method; `ARCHIVED` is terminal and reversible |
| **I2** Automatic transitions apply only to `agent`-created skills | A provenance gate, checked per skill |
| **I3** A pinned skill is exempt from every automatic transition | Checked unconditionally, including for `retire()` |
| **I4** No automatic path validates a skill | Promotion requires recorded checks that all passed; there is no "trust the agent" branch, because the agent is the thing being governed |
| **I5** A disabled skill is not a curation candidate | Excluded from the walk, so it is not rewritten either |

Each invariant has a test, and each test was verified to bite by removing the enforcement
and confirming the suite fails: removing the provenance gate fails one test; removing the
pinned exemption fails one; making candidates loadable fails three; skipping the evidence
requirement fails one. The source files were restored byte-identically afterwards.

I1, I3 and I2's provenance gate are adopted from Hermes Agent's documented curator
invariants. See [`10-hermes-audit.md`](10-hermes-audit.md) §3.1 for what was taken and
what was deliberately not.

**One bug found by the tests rather than by reading.** `curate()` originally set
`updatedAt` on each transition, which reset the idle clock — a skill that went stale on day
31 then measured its archive threshold from day 31, needing `staleAfterDays +
archiveAfterDays` of idleness instead of `archiveAfterDays`. Two tests failed for a reason
that had nothing to do with the assertions they appeared to be making. The tests were wrong
about the clock in one place too (they advanced the curator's clock while the registry used
the real one), and that is recorded here because "the test failed" is not the same as "the
code was wrong".

### 2.2b L2 in detail — memory that cannot remember on its own behalf

The directive requires user-approved memory to be inspectable, editable and deletable,
and requires it to stay distinct from contextual memory, retrieval indexes and training
data. `services/core/src/memory/store.mjs` implements it, and the distinctions are
enforced rather than described:

| Property | How it is enforced |
|---|---|
| Nothing is remembered without the user | The `approved_by` column carries `CHECK (approved_by = 'user')`, so the database refuses an agent-approved row |
| Memory is never training data | Every row carries `CHECK (training_use = 'prohibited')`; the restriction travels in the export too |
| A proposal cannot reach a prompt | `contextFor()` reads a view filtered on `status = 'approved'`; a candidate lives in a different table with no path into a prompt |
| Deletion is real | `forget()` removes the row, its index entries and writes a tombstone that records *that* a deletion happened, never what it said |
| Recall is not memory | `recall()` searches the user's own turns on demand and returns each hit with its session and role |
| Memory is local | Its own database file, and a test drives the store with egress blocked and a fetch recorder, asserting **no network call is attempted** |

The gate has a user interface. L2 was implemented for one commit with no way to reach it:
a memory store whose approval step is only callable through the API is a memory system
that cannot be used as intended, because the whole point of the gate is that a person
decides. `apps/web/src/areas/ChatArea.jsx` now carries two panels inside **Chat** — never a
sixth navigation entry:

| Panel | What it offers | Where the promise is kept |
|---|---|---|
| **Memory you approved** | List, add, edit, delete, delete everything, search, and **approve or reject each pending proposal** | The candidate card says in words that a proposal is not a memory and is not injected; the composer's switch reads *Use what I asked you to remember* and is off by default |
| **Conversation history** | List stored sessions with their turn counts, search your own past turns, delete a session | A search that finds nothing says how many turns it searched and that **nothing was invented to fill the result** |

The panel also states its own limits from the store's `limits` block, and when the list
comes back full it says so rather than implying those are all of them. Deletion is real in
the interface — the confirmations report the counts the server actually returned, and a
duplicate is reported as a duplicate rather than as a second copy. Export is now reachable
too (`GET /api/memory/export`), so "delete and export" is one right rather than half of one.

One defect the interface's own test found, worth recording: `forgetAll()` failed with
`FOREIGN KEY constraint failed` for any user who had ever approved a proposal. Both
`memory_candidates.memory_id` and `memories.superseded_by` reference `memories`, and with
`PRAGMA foreign_keys = ON` the wipe deleted the memories before the rows pointing at them.
Approval is exactly what the panel is for, so the feature's headline promise — real
deletion — was broken for the memories that came through the gate. The delete paths now
release the references first; the decision records survive and lose only the pointer to a
row that no longer exists.

Two properties are worth calling out because they were bugs before they were features:

**Egress is decided on the assembled request, not on the question.** Memory injection and
document retrieval both add text to a prompt, so both can raise its sensitivity. The chat
path now builds the full context first and takes the most sensitive class of everything in
it. Before this, a public question that retrieved a confidential chunk was classified
public and could have been sent externally: the retrieval path was an exfiltration channel
with a friendly name. The decision is shared by the streaming and non-streaming paths
through one implementation, because there were two copies and one of them would have been
missed.

**Two independent layers, discovered by a control that failed to bite.** The first
attempt at proving "a candidate cannot reach a prompt" removed the index filter and the
test still passed. The reason is that `contextFor()` re-checks the row's status when it
hydrates a hit. The control was rewritten to defeat both layers and then the test failed
as it should — the guard is defence in depth, which is a better answer than the one the
control was looking for.

### 2.3 L5 and L6 — what the training system can and cannot do here

`services/fabric` implements data validation → base selection → domain training → SFT →
preference optimisation → distillation → evaluation → release as a single reproducible
pipeline. **Stages 4, 5 and 6 report themselves blocked on this host** and say what they
would need; a run containing a blocked stage is never eligible to release the artifact that
stage would have produced. This is the mechanism behind the honest status column above.

L6 has one real promotion and one real rejection:

- **Promoted:** `aetheris-lite-lm-0.1.0`, which cleared the hard gate
  (`pplVsBigram ≤ 1.0`, `unknownRate ≤ 0.02`, `lossImprovement ≥ 1.0`), with a committed
  model card, a weights digest and a rollback path.
- **Rejected:** logit-level distillation from our own released model, on all three seeds,
  with the acceptance rule "same sign every seed AND `|mean| > spread`". The primary
  condition regressed by 0.0922 perplexity points and the untrained-teacher control by
  0.3105 — the control was *worse*, which is what makes the result worth recording. See
  [`09-distillation.md`](09-distillation.md) §5.

The rejection is the more useful of the two: it is evidence that the gate refuses a change
that a looser process would have shipped as an improvement.

### 2.4 Privacy separation — five things that must not be merged

The directive requires the following to stay distinct, and the distinction is enforced by
where the data lives rather than by a policy statement:

| | What it is | Where it lives now |
|---|---|---|
| Contextual memory | The current session's context | In the request; nothing is written |
| User-approved memory | Facts the user asked to keep | `memory.sqlite` — approval is a database `CHECK`, so a row cannot be written without one |
| Reusable skills | Procedures, not data | `skills/` — validated documents, no user content |
| Candidate training data | Failures and feedback that *might* train | `fabric/failure_memory.py`, behind a triage gate and a privacy filter that refuses credential material |
| Released weights | A promoted artifact | Gitignored, referenced by digest, with a model card |

**No personal conversation or document is auto-trained on.** Company-private material
defaults to local processing, and the path from a captured failure to a regression case
refuses credential material outright, because a regression suite is exactly the kind of
artifact that gets committed.

---

## 3. What is not built

Stated plainly, because §7 of the directive asks for it and because a list of what exists
without a list of what does not is a sales document:

- **Klyvaron Pro and Max do not exist.** No artifact, no measurements, no plan that has
  produced a file. On this host no route to a model registry exists and there is no GPU,
  so obtaining base weights is not possible; the tiers are unbuilt rather than pending.
- **Lite does not chat, translate, summarise or reason.** Only `text.completion` and
  `text.extract` are backed.
- **L2's user interface does not cover superseding.** The panel lists, adds, edits,
  deletes, exports, searches and decides proposals; the store's `supersede()` — replacing a
  memory with a corrected one while keeping the link to what it used to say — is implemented
  and tested but still has no control. Editing a memory in place is offered instead, which
  loses the history that superseding preserves.
- **L4 transfer testing produced a null, and nothing selects a strategy at run time.**
  The transfer test is implemented (`services/fabric/fabric/transfer.py`) and has been
  run over eight seeds and four task families: the a-priori baseline was the best
  strategy on the selection family, so no lesson qualified to be transferred and the
  held-out families are recorded as observations. That is the requirement — *test
  transfer and record non-generalisation* — met with a negative result, not a positive
  one. The platform still serves the a-priori 0.5/0.5 fusion; no component picks a
  strategy from experience while serving a request.
- **LoRA/PEFT, external distillation and local video generation cannot be exercised here.**
  The external distillation path exists behind an explicit authorization object and a
  redaction gate, and **has never been run against a real provider** — it is
  *Requires external credentials*, not working code.
- **Loading a learned procedure is still the user's decision.** The skills subsystem is
  reachable over fourteen routes and from the review panel in Chat, but nothing loads a
  procedure automatically while a task is running: a skill is matched, shown and loaded
  on request. Auto-proposal from a live task is the remaining gap at this level, and
  `docs/03-status.md` §"what remains" tracks it.

Nothing in this document should be read as a claim of parity with any other model family.
Lite is a 359,616-parameter character model that beats three computed baselines on
perplexity, trained from random initialisation on this repository's own text. That is the
whole claim.
