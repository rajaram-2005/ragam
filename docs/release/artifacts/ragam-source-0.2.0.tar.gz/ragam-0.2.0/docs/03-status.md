# 03 — Implementation status

> **Active product: online-only, with a local Docker workspace and an opt-in hosted BYOK edition.** Docker remains the default loopback-only, single-user deployment; an optional LAN overlay uses shared Basic Auth and Caddy internal HTTPS but is not public hosting. Hosted mode is a separate Vercel/Supabase build with per-user accounts and encrypted provider settings; public registration requires configured transactional email. See [22-self-hosted-deployment.md](22-self-hosted-deployment.md) and [30-hosted-byok.md](30-hosted-byok.md). Suite totals include retained legacy coverage.

Every claim below is tied to a test, a measurement or a named limitation. Where
something does not work, it says so and says why.

**Core test environment for this implementation pass:** Node v22.22.3 · Python 3.11.2 · isolated `.venv` with NumPy 2.4.6 · **no GPU**. The workspace contains no Klyvaron model-weight artifacts; optional legacy artifact-dependent checks are separate and are not prerequisites for the built-in processor. Reachable package hosts include `github.com`, `codeload.github.com`, `api.github.com`, `registry.npmjs.org`, `pypi.org` and `files.pythonhosted.org`.

**Test inventory: 2051 cases across the three suites** (Core 1,085, Web 143, Fabric 823). The earlier full CI run [41324293475](https://github.com/rajaram-2005/ragam/actions/runs/41324293475) passed the then-present 1,907 tests (Core 976, Web 109, Fabric 822). The latest completed full CI run [41394564087](https://github.com/rajaram-2005/ragam/actions/runs/41394564087) passed all 1,916 tests and six jobs, including release verification and the loopback-only Docker Compose health/persistence/restore smoke. Since that run, follow-on onboarding, history, project organization, Chat parity, hosted BYOK and Manufacturing Operations media guidance have expanded the suites. In this sandbox, the full Core suite passed 1,081/1,085 with four skipped real-artifact acceptance cases because the ignored Pro/Max fixtures are not installed; the test itself remains unchanged apart from a larger timeout. CI runs Core test files serially and no longer cancels an in-flight acceptance run when a newer commit arrives. The legacy artifacts are downloaded only for that compatibility test, never for application startup or desktop packaging. Web passed 143/143 and the production bundle built. Fabric passed 823/823 with NumPy, JAX, PyAV and Pillow installed in an isolated venv; no optional training test was skipped or failed. Full CI for this current tree is recorded in the pull-request checks and final engineering report. The tracked [36 — Final engineering report](36-final-engineering-report.md) records the passing `main` CI run [42352898134](https://github.com/rajaram-2005/ragam/actions/runs/42352898134) and Desktop run [42352898123](https://github.com/rajaram-2005/ragam/actions/runs/42352898123) on `36fef57`. The documented-provider API contracts use deterministic fixtures, not live vendor access. The Compose smoke verifies a synthetic local single-user workspace, disabled account creation, provider catalogue, restored workspace ID and a SQLite conversation-history marker; it is not a permanent deployment or live-provider inference. A read-only inventory of the external `ragam-core` Supabase project on 2026-11-01 found 28 Ragam public tables with zero rows, zero `auth.users`, zero `storage.objects`, and one private `ragam-media` bucket. For hosted BYOK, migration `20261103110151` now adds an empty, RLS-protected `byok_provider_connections` table. The existing Supabase project Site URL/redirect allow-list now use the production Ragam origin, and sign-up is deliberately disabled until SMTP is configured. Production-only Core environment variables are present in the existing Vercel `ragam-core` project; no production deployment has been made. Vercel currently reports deployment SSO protection for non-custom domains, so public access also needs to be enabled or a custom domain selected. No provider key was created/read/used and no live provider call was made.

| Suite | Command | Result |
|---|---|---|
| `services/core` | `node --test test/*.test.mjs test/klyvaron-release/*.test.mjs` | **1085 tests** (78 files; previous full suite passed in CI at [41394564087](https://github.com/rajaram-2005/ragam/actions/runs/41394564087) with Python prerequisites; that CI result does not establish a Klyvaron model release; Baidu Qianfan has deterministic fixture coverage) |
| `services/fabric` | `npm run test:fabric` | **823 tests** (42 files; 823/823 passed locally in an isolated venv with the optional Python media dependencies) |
| `apps/web` | `npm run test:web` | **143 tests** (10 files; 143/143 passed locally) |
| `apps/web` build | `npm run build --prefix apps/web` | production bundle built successfully locally |

### Model-independent Klyvaron processor — implemented, bounded

The active built-in Klyvaron text path is `klyvaron-deterministic-v1`; it does not require an AI model, model weights, training, download, provider credentials, or network access. Chat defaults to this path. Lite, Pro and Max are bounded resource/workflow profiles (16k/64k/100k input characters, respectively), not trained-model sizes or quality promises. The processor provides inspect, extractive summarize, pattern extraction, structural outline, lexical comparison, bounded arithmetic, and opt-in account-local BM25/memory retrieval. Text and browser-extracted document text are supported; binary image/audio/video understanding and open-ended language reasoning are not.

`POST /api/klyvaron/process` is authenticated, account-scoped, rejects unknown fields, and persists supplied text only on explicit `saveToKnowledge: true`. Workflow failures do not save. Its response identifies model/weights/network use as false and lists limitations. A selected session stores user and processor turns in that account's session store. Synthetic tests verify deterministic behavior, ACL isolation, limits, opt-in persistence and the HTTP route; they do not establish general intelligence or real-world task success. See [33 — Model-independent Klyvaron](33-model-independent-klyvaron.md).

Provider-backed inference and legacy model-training/release work remain optional, separate paths. Their release evidence gates still apply to any model-specific claim; they are not prerequisites for the built-in processor.

### Legacy licensed-foundation Klyvaron assistant track — separate model path

This release track did not have a pre-existing fixed phase count. The current working plan has ten phases; it is not a completion claim or delivery estimate. It is separate from the ten-phase Klyvaron adaptive-intelligence directive documented in [25](25-adaptive-intelligence.md).

1. **Registry and fail-closed release gates — implemented structurally.** Model records, state transitions, evidence requirements and restart validation exist; coverage uses synthetic evidence.
2. **Provenance metadata and local byte verification — implemented as intake primitives.** Metadata validation and local hash/size reports exist, without source fetching or source authentication.
3. **Purpose-scoped, replay-resistant attestations — implemented structurally.** Foundation, dataset provenance, dataset-byte integrity, artifact and release purposes are distinct; dataset review and byte attestations bind model, dataset ID/version and provenance-manifest digest. No operator trust anchor or trusted production evidence is provisioned.
4. **Verifier-generated local dataset intake report — implemented structurally.** `dataset-intake.mjs` composes metadata validation with local byte hashing and prepares unsigned, dataset-bound review/integrity payloads. It performs no network fetch and explicitly leaves source authenticity unestablished; trusted source intake remains open.
5. **Reproducible training and Adaptive evaluation evidence — implemented structurally.** Canonical run/evaluation report builders, `training_run` and `held_out_evaluation` signatures, and lifecycle gates now bind the model, dataset manifest, configuration, artifact, explicit user consent and Adaptive evaluation result. The schema enforces paired-user-computer execution, no private-chat auto-ingestion, the interactive 120-second cap and a separately approved longer-training budget. No real training or evaluation run has been recorded.
6. **Per-tier release qualification gate — implemented structurally; real qualification pending.** A signed report must bind the exact artifact/tier and measured RAM, cold-start, inference and rollback evidence for Windows, Linux and macOS; runtime availability is bound to one tested platform/runtime row. No real deployment qualification, artifact, or tier release has been verified.
7. **Typed platform measurement evidence — implemented structurally; actual captures pending.** Cold-start, inference-suite and rollback records now carry canonical metric-bearing reports bound to model, tier, artifact, platform, measured hardware, runtime, environment and run. The schema rejects incomplete inference suites and failed artifact restoration; report builders do not run workloads or authenticate the truth of submitted measurements.
8. **On-host qualification capture runner — implemented structurally; no real tier capture possible yet.** `qualification-capture.mjs` reads the actual OS, architecture, CPU and RAM; verifies local artifact bytes; invokes explicit runtime and deployment adapters; times cold start, inference and rollback; and emits nothing signable unless the inference suite passes and the known-good artifact is restored and read back. It cannot impersonate another OS and has only synthetic adapter tests here. No licensed-foundation assistant artifact or real runtime adapter is qualified on this host.
9. **Operator evidence audit and signing procedure — implemented structurally; production signing pending.** `qualification-ceremony.mjs` assembles three host captures into an unsigned report and canonical offline signing request, then verifies an externally signed report only against an operator-managed public trust store. It never loads or creates private keys. The operating sequence and limitations are in [32 — Klyvaron evidence signing](32-klyvaron-evidence-signing.md). No production key, trusted capture, or signature is provisioned.
10. **Family release decision evaluator — implemented structurally; real per-tier decision pending.** `release-decision.mjs` returns per-tier ready/blocked decisions only when signed lifecycle gates and matching target deployments pass; it reports partial readiness without turning it into a family-wide claim. Evaluating the current registry remains blocked: no signed production evidence or all-OS deployment evidence exists. Real per-tier Windows/Linux/macOS qualification and the release/rollback decision still require those executions.

### Licensed-foundation Klyvaron assistant plan — registry increment

- `services/core/src/klyvaron/model-registry.mjs` defines the release states, transition constraints, evidence gates and deployment-aware availability predicate. `model-registry-store.mjs` persists state atomically in the installation's private data directory and refuses to reset unreadable state. `tiers.mjs` seeds it with the existing research identities plus three separate Lite/Pro/Max assistant records; the snapshot is exposed through the authenticated `/api/klyvaron` view and shown as a non-selectable plan in Provider Settings.
- The new assistant records are all `planned`, with no foundation, reviewed license, training data, trained artifact, evaluation report, hardware qualification, model card, signature or availability claim. Target parameter sizes are intentionally unset until foundation-license, quality, runtime, hardware and cost evidence supports a choice.
- The release-candidate evidence schema requires exact foundation revision and approved license review; versioned data provenance/privacy/deduplication; reproducible training records; checked artifact checksum; pinned tokenizer and chat template; held-out plus out-of-domain evaluation; measured runtime compatibility and hardware; complete release metadata; and a verified signed manifest before release. It additionally requires a signed per-tier qualification report binding the exact model, tier, artifact and supported runtime, with measured hardware plus cold-start, inference and rollback evidence for Windows, Linux and macOS. Deployment availability must match the exact qualified platform, architecture, hardware evidence, RAM minimum and runtime version. The artifact gate rejects a bare `integrityVerified` boolean and checks that a successful local-file report's manifest/report digests, per-file hashes, total bytes and artifact digest/size agree. `evidence-trust.mjs` verifies purpose-scoped Ed25519 attestations for foundation license reviews, dataset provenance and dataset-file integrity, reproducible training runs, Adaptive held-out evaluations, tier release qualifications, model artifact-integrity reports and release manifests against operator-managed public keys in `<dataDir>/klyvaron/evidence-trust.json`; the trust store is empty by default and no browser route mutates it. These signatures authenticate an attesting key, not the legal truth of its statements or the source of caller-pinned hashes. Runtime availability also requires the matching verified deployment. Synthetic tests exercise only report schema and gate behavior; no real qualification/deployment/rollback evidence exists.
- **Not yet implemented:** a trusted training/release pipeline that can produce verifier-generated evidence or advance these records from real training. The durable transition store is exercised with synthetic test evidence only; that test is not evidence of a selected foundation, training run, assistant artifact, benchmark, deployment or support commitment. Foundation/license selection remains pending verification.

### Provenance intake increment

- `services/core/src/klyvaron/provenance.mjs` adds metadata-only foundation and dataset manifest validators. Foundation records must pin an immutable revision and license-document digest and include a dated, named license/rights review. The validator does not approve licenses, fetch sources or determine legal meaning.
- Dataset records require per-record source/license references and explicit review rights, privacy/deduplication review digests, SHA-256 opaque record IDs, and disjoint train/validation/held-out/out-of-domain splits. Raw prompts, responses, user chats and other unlisted content fields are rejected; the metadata validator itself does not read dataset bytes. Before release, dataset bytes must also match a separate local-file integrity report. Both model-bound dataset attestations (`dataset_provenance_review` and `dataset_artifact_integrity`) now sign the exact dataset ID, version and provenance-manifest digest, so review or byte evidence cannot be replayed under another dataset identity or manifest.
- `services/core/src/klyvaron/local-provenance.mjs` adds a local-only streaming SHA-256 verifier for files staged under a private, quiescent directory. It checks caller-pinned digests and required byte lengths; rejects traversal, symlinks, changed-during-read files, and configured size-limit breaches; and returns hashes/status only, never file contents. It does not fetch sources or authenticate who supplied the expected digest.
- `services/core/src/klyvaron/dataset-intake.mjs` composes the metadata validator and local file verifier into one fail-closed intake result, returns the evidence record plus unsigned purpose-scoped payloads for explicit offline signing, and records `sourceAuthenticity: not_established`. Invalid metadata stops before reading files; byte mismatches produce no signable payloads.
- `services/core/src/klyvaron/training-evidence.mjs` prepares reproducible training-run and held-out evaluation reports, recomputes their canonical digests, and delegates evaluation acceptance to Adaptive. It requires explicit consent, a paired user-computer worker, no private-chat auto-ingestion, reproducibility pins, a local artifact digest, an enforced 120-second interactive adapter cap, and a separately approved budget for longer work; it creates unsigned `training_run` and `held_out_evaluation` payloads only. No training process is started by this report module.
- `services/core/src/klyvaron/qualification-capture.mjs` is a host-bound capture coordinator: it reads OS/architecture/CPU/RAM locally, verifies the exact staged artifact bytes, runs supplied model-runtime and deployment adapters, measures elapsed time, and confirms candidate deployment rollback by digest readback. It emits a target report only after every inference case passes and prior-artifact restoration is verified. The adapter tests use synthetic fixtures; the coordinator has not run a Klyvaron assistant model or qualified another OS.
- `services/core/src/klyvaron/qualification-ceremony.mjs` validates exactly one successful capture per supported OS, prepares an unsigned canonical `tier_release_qualification` signing request, and audits signatures against the operator's public-only, purpose-scoped trust store. It contains no private-key operation; production custody and independent human review remain operator responsibilities. See [32](32-klyvaron-evidence-signing.md).
- `services/core/src/klyvaron/release-decision.mjs` evaluates the canonical Lite/Pro/Max records independently and requires a trusted released record plus exact deployment evidence for every measured OS target before marking a tier ready. It reports blocked/partial states explicitly and does not run or attest deployment tests.
- `services/core/src/klyvaron/platform-measurement-evidence.mjs` defines canonical cold-start, inference-suite and rollback reports. Each binds model, tier, exact artifact, OS/architecture, hardware-report digest and RAM, supported runtime/version, environment, run ID and timestamp. It requires numeric measurements and evidence digests, all inference cases passing, and rollback restoring a distinct prior artifact. It prepares records only; it does not execute or attest measurements.
- `services/core/src/klyvaron/qualification-evidence.mjs` builds a canonical aggregate report from those metric-bearing records for one exact model/tier/artifact/runtime. It requires all three report kinds on each of Windows, Linux and macOS, and deployment availability must match the exact qualified target. Synthetic fixtures test the schema and gates only; no actual measurements were captured.
- `services/core/src/klyvaron/evidence-trust.mjs` verifies Ed25519 signatures over canonical, model-bound, purpose-separated evidence digests. Only public keys enter its trust store; each key must be explicitly scoped to known purposes. The installation trust file is operator-managed and absent/empty by default. Tests use a transient keypair that is never written to the repository or product data.
- The registry now requires verified attestations at the relevant transitions and revalidates persisted assistant release stages on restart; an unverifiable candidate/released stage fails closed instead of being shown as released.
- These are intake/verification building blocks only: there is still no selected foundation or dataset, no legal approval, no authenticated source-fetch pipeline, no real trusted signed evidence, no trained open-foundation model, and no public or local inference availability. No private chats are collected.

**Archived model-artifact assertions are not release evidence.** Earlier records and model-card metadata in this repository describe model-training experiments and list digests, but the current checkout contains no corresponding weight payloads and the release evaluator blocked Lite, Pro, Max and the family. None is a production model release or available Klyvaron capability. The active product path is the deterministic processor documented in [33](./33-model-independent-klyvaron.md); keep any remaining model-training and artifact tooling explicitly separate from it.

All three suites run in CI on every push and pull request
([`.github/workflows/ci.yml`](../.github/workflows/ci.yml)), as six jobs split so a
failure names the component that broke. The fifth runs all three suites, counts what they
reported, and passes those counts to the release verifier — a release gate that read the totals out
of the document it was checking would verify nothing. The CI run also asserts two properties that
are easy to lose silently: that `services/core` still declares **zero** npm
dependencies, and that the Fabric release gate refuses an undertrained model rather
than merely accepting a trained one.

For Phase 2, superseded offline UI expectations were replaced with online-only UI requirements; the legacy Core and Fabric regression suites remain. Two earlier assertions in
`services/core/test/http.test.mjs` were rewritten when built-in plugins arrived —
they had counted absolute registry size, and now assert about the plugin the test
installed *and* separately verify the built-ins are present, enabled and bound.
That is a stronger claim than the count it replaced.

For the own-models increment, Pro and Max stopped being a composition of somebody else's
weights and became presets of this family's architecture: `aetheris-core-v1` is recorded in
`klyvaron/architecture.mjs` with its parameter arithmetic, and the two differentiators are parts of
the model rather than wrappers around it. `services/fabric/tests/test_lm_model.py` gains
finite-difference checks for the new arrays, and a prototype trained them in one loss on generated
data (`docs/experiments/differentiator-prototype.json`, 900 steps, CPU). No weights exist, so the
tiers stay `unbuilt` — see [24 — Own models](./24-own-models.md).

For the accounts increment, the operator-token sign-in was **removed rather than
supplemented**: `services/core/test/accounts.test.mjs` (20 tests) covers scrypt password
storage, lockout scope, enumeration resistance, throttling, session bounds, owner-only
gateway control and per-account data isolation, and the web suite grew by 8 tests for the
three sign-in pages. `online.test.mjs` now signs in with an account. See
[20 — Accounts and sign-in](./20-accounts-and-sign-in.md).

---

## Hardware policy update

[13 — Hardware execution policy](./13-hardware-execution-policy.md) is the current
Lite / Pro / Max contract. Measured hardware discovery, fail-closed GPU admission,
CPU allocation guards, execution-mode controls, stream locality, retained drafts
and wider managed-directory accounting have regression coverage. Native mobile
support, useful quantized Lite weights, GPU runtime adapters and real Pro/Max
benchmarks are **not delivered**. Synthetic admission tests are not GPU benchmarks.

[14 — CPU int8 inference](./14-cpu-int8-inference.md) adds versioned quantized
artifacts, compressed resident matrix weights, conversion quality gates and a
repeatable CPU benchmark. Numerical test fixtures are not assistant releases.

[15 — Responsive local execution](./15-responsive-local-execution.md) adds a
shared CPU worker, bounded incremental streaming, disconnect cancellation,
deadlines and lazy residency after startup verification. Sixteen execution tests
cover these boundaries; they do not qualify a useful assistant or a mobile device.

## Universal ecosystem update

The 2026-10-14 master directive supersedes the earlier decision to exclude online
providers. [16 — Integration map](./16-universal-ecosystem-roadmap.md) tracks all
requested deliverables and blockers. [17 — Model catalog](./17-model-catalog.md)
adds a tested, opt-in metadata registry and in-Chat search. It does **not** add
online inference, useful assistant weights, industry packs or durable task recovery.
Earlier “complete” labels below refer to the original, narrower integration scope.

## 1. Status vocabulary

Used consistently throughout, per the reporting requirement:

| Status | Meaning |
|---|---|
| **Implemented and tested** | Code exists and a test exercises it in this repository |
| **Implemented, not fully tested** | Code exists; coverage is partial or indirect |
| **Prototype / simulation only** | Runs, but does not do the real thing |
| **Requires external credentials** | Cannot be exercised here without a secret |
| **Requires weights or hardware** | Cannot be exercised here without a download or a GPU |
| **Planned, not implemented** | Designed, no code |
| **Blocked by permissions/infrastructure** | Environment prevents it |

There is **nothing in the "prototype / simulation only" category**. Upstream
Aetheris's in-browser simulation layer was not ported, and no substitute was
written. Where a capability cannot be real on this host it reports a limitation
instead.

---

## 2. The twelve phases

| # | Phase | Status | Evidence |
|---|---|---|---|
| 1 | Repository audit | **Complete** | [`01-audit.md`](./01-audit.md): per-repo findings with `file:line` evidence, licence table, integration map, baselines re-run |
| 2 | Integration design | **Complete** | [`02-architecture.md`](./02-architecture.md) |
| 3 | Unified app, five areas | **Complete** | `apps/web`; 130 tests including "exactly five areas", "no internal service is a navigation entry", server-rendered markup for all five areas, and a guard against the re-export bug class |
| 4 | Local inference with ≥1 real local LM | **Partially met** | A real local LM now runs here end to end: the from-scratch 359,616-parameter model is exported as a versioned artifact, loaded by the core in plain JavaScript, and served through the normal provider path — with its logits checked against NumPy on identical bytes (`klyvaron-runtime.test.mjs` 11, `klyvaron-store.test.mjs` 10, `klyvaron-app.test.mjs` 7 — 28 tests; another 20 pin the tier record's own claims). Full-size artifacts were trained, verified, installed into the model library and served over HTTP from the store (1.4 MB; 359,520 parameters at `67cdd58` and 359,616 at `8d9cdf8` — `docs/experiments/lm-verification-run-67cdd58.json` and `docs/experiments/lm-verification-run-8d9cdf8.json`), so the path from a training run to a served local model is demonstrated rather than only unit-tested; the second run's corpus is rebuildable from its commit, and the update/rollback exercise behind it found and fixed a storage-accounting defect in the model library (`store.mjs`: a replace used to leave the previous version's weights behind, and to report the source directory's size as the device's). What is still unmet is a local **assistant**: the artifact is a base completion model, `/api/chat` refuses it unless the user pins it by id (`model_not_instruction_tuned`, 501, with the model's own limitations attached), and the Ollama/llama.cpp adapters remain proven only against a loopback fixture ("Phase 4 in detail", below) |
| 5 | Online provider integration | **Contract-tested; live vendor qualification pending** | The online entry routes provider-specific chat, image and video wires through one guarded transport, with destination checks, per-revision consent, deadlines and size limits. Twenty-three catalogue entries are `ready`: two local runtimes, six other native chat protocols, nine cloud image adapters, one local ComfyUI adapter and five video adapters, each fixture-tested. Twenty-two individually adapted Chat APIs are classified as native vendor, OpenAI-compatible or gateway-routed; this batch adds Alibaba Cloud Model Studio, Cerebras, DeepInfra, MiniMax and SiliconFlow. Their live verification remains pending; no authorized vendor credentials or quotas were available in this sandbox |
| 6 | Secure private memory | **Complete** | Knowledge pipeline + ACL + retention + audit; 40+ tests |
| 7 | Tool / agent execution | **Complete** | Plugin and MCP permission enforcement; God Core lifecycle |
| 8 | Multimodal pipelines | **Complete** | Job queue, validation, video genuineness check |
| — | Procedural skills (meta-learning L3) | **Partial** | Documents on disk with append-only history, evidence-gated promotion, rollback, deletion tombstones and lexical relevance matching — reachable over 12 routes and from a panel inside Chat. **Partly closed 2026-10-16:** the adaptive loop does both things this row used to say nothing did — it offers a stored procedure to a task as a candidate route without being asked, and it proposes one from a recorded verified success — demonstrated end to end for one capability ([docs/25](25-adaptive-intelligence.md) §4). What remains partial is the product surface: no HTTP route or Chat panel runs the loop, and its routing choice comes from a *fresh* measurement on the current input rather than from what past tasks showed |
| 9 | Sparsiz integration | **Complete** | Responsibility defined; taxonomies and `Q(x)` adopted, scoring replaced |
| — | Legacy Klyvaron artifact format and optional model runtime | **Complete** | `klyvaron/format.mjs` (manifest + digest verification, a ZIP/`.npy` reader in the core), `klyvaron/runtime.mjs` (the forward pass in JavaScript, parity-checked against NumPy), `klyvaron/store.mjs` (install/verify/load/remove inside the storage budget), `providers/klyvaron.mjs` and `scripts/export_lm.py`; a committed parity fixture ties the two implementations together |
| — | On-device storage accounting | **Complete** | `storage/budget.mjs` plus `klyvaron/footprint.mjs`; `/api/storage` reports measured bytes, verification results and headroom |
| 10 | Legacy Fabric model experiments (separate from Klyvaron) | **Archived research** | The retained NumPy retriever and from-scratch character-LM experiments are not the active Klyvaron processor and do not establish a production Klyvaron model release. They are not required for user-authorized knowledge or memory. |
| 11 | Legacy Fabric benchmark cycle (separate from Klyvaron) | **Archived evaluation** | Historical BM25 and small-model comparisons remain in the experiment docs. They are not evidence for general language reasoning or a Klyvaron release. No Mistral/Qwen/Llama/Gemma/DeepSeek comparison was completed. |
| — | Sparsiz improvement cycle on a real failure | **Complete** | [`07-improvement-cycle.md`](./07-improvement-cycle.md): rejected run diagnosed, hypothesis tested, regression cases promoted; the accepted `mrr` gain **did not replicate** across seeds and is recorded as such; 66 tests |
| — | Legacy Fabric selection-protocol correction | **Historical experiment record** | [`06-benchmarks.md`](./06-benchmarks.md) §5.3 documents an experiment-side selection correction. It does not constitute a production Klyvaron model release. |
| — | Legacy Fabric robustness measurement | **Historical experiment record** | `scripts/robustness.py` records seed and training-size experiments for the separate Fabric retriever path; it does not qualify the active Klyvaron processor. |
| 12 | Release readiness docs | **Complete** | This document plus 04, 05, 06 and the model card |
| — | Archived from-scratch language-model experiment | **Complete** | [`08-aetheris-lite.md`](./08-aetheris-lite.md): character-level transformer, 98 new tests including every gradient against a finite difference. Found and fixed a real positional-gradient bug the numeric check reported as `pos: exceeds tolerance by 1.6e-01` |
| — | Legacy optional remote-training research | **Built; smoke run not executed; not required** | [`21-remote-training.md`](./21-remote-training.md) records an unexecuted experiment using a pinned base and synthetic starter data. It is separate from Klyvaron’s built-in deterministic workflows and from explicit knowledge/memory persistence. No Pro or Max model was trained or released. |
| — | Historical Klyvaron model differentiator specifications | **Archived specifications; no model artifact** | [`22-klyvaron-differentiation.md`](./22-klyvaron-differentiation.md) describes unbuilt model capabilities. Trend and expressed-history features are not part of the built-in processor; no image, video or voice model capability is claimed by the model-independent path. |
| — | Klyvaron model-weight work (superseded; not a model release) | **Not active; no production model released** | Earlier experimental model-training notes and model cards remain in the repository as historical records only. The active Klyvaron path uses `klyvaron/processor.mjs`: deterministic parsing, extraction, extractive summaries, lexical comparison, bounded arithmetic and opt-in local retrieval. It requires no weights, training, downloads or provider; Lite/Pro/Max are resource/workflow profiles. Do not interpret prior artifact descriptions or training claims as proof of a released model. |
| — | External provider/model selection (online) | **Independent of Klyvaron profiles** | `GET /api/klyvaron` exposes `modelIndependentProcessor` metadata and Lite/Pro/Max resource profiles. External Chat and media integrations use their own explicitly selected provider/model; there is no tier-to-provider mapping. Legacy tier-mapping routes return Gone, and persisted legacy mappings are discarded during store migration. |
| — | Universal provider framework and Phase 3–9 orchestration | **Partially implemented; Provider fabric Phase 2 and local orchestration contract-tested** | [`27`](./27-provider-framework.md): a 46-entry catalogue with per-capability evidence, capability selection with explainable refusals, provider-specific safe error normalization, `GET /api/providers/catalog` and a matrix in Provider Settings. Twenty-three entries are `ready` and fixture-tested, including the direct local ComfyUI image adapter. Twenty-two Chat APIs have distinct contract adapters: native-vendor (OpenAI, xAI), OpenAI-compatible (seventeen vendors), or gateway-routed (OpenRouter, Perplexity Router, Hugging Face). All twenty-two are contract-tested; live verification remains pending. Phase 2 adds a versioned, local-only provider fabric snapshot with normalized error envelopes, model-discovery metadata, local/cloud state, health/evidence states, cost/latency measurement scaffolding, explainable routing and an opt-in live-qualification gate that fails closed. Phase 3–9 adds authenticated `/api/orchestration/plan` and `/api/orchestration/execute` routes with a versioned task envelope, bounded DAG validation, local-only deterministic workflows and explicit refusals for live/model/sandbox/deployment capabilities. Evidence state is **contract-tested, not live-verified**. Model metadata is retained without inferring unreported features. Diffusers remains pending because the Python library has no standard HTTP inference API; no model service or weights are installed. The store holds several connections, each with an encrypted credential, model list/details and separate successful-inference markers; no live vendor call has been made |
| — | Legacy Fabric retriever release gate (not a Klyvaron model release) | **Complete** | `fabric/lm/card.py` drives the existing `ModelReleaseManager`. Hard requirements: beat the bigram baseline, unknown-rate ≤ 2%, loss must fall. The rejection path is tested more than the acceptance path |

### Phase 4 in detail — the most important limitation

`services/core/src/providers/local.mjs` implements the Ollama and
OpenAI-compatible (llama.cpp) protocols for real. `offline.test.mjs` starts a
**real `node:http` server on loopback speaking the Ollama wire protocol** and
completes a genuine chat round-trip under `strict_offline` — the response carries
`sentExternally: false` and `modelId: 'ollama:tiny-local:latest'`.

What that proves is the **plumbing**: routing, policy, provider adaptation,
streaming, audit. What it does **not** prove is that a language model is
installed, because none is. `huggingface.co` is unreachable and there is no
`ollama` binary on this host, so no weights could be obtained.

The startup banner states this rather than hiding it:

```
readiness     degraded
local models  0 ready
limitation    no local chat model is installed; /api/chat will return no_model_available
limitation    no video generation model is available; /api/video will refuse rather
              than substitute a still image
```

`/api/ready` returns `capabilities.chat = false`, and the web UI renders a
`no model ready` chip and an empty model table. **No model is invented anywhere.**
Install Ollama and pull any model, then re-probe, and the same code path serves
real inference — that is the design, and the loopback test is its evidence.

#### Archived language-model experiment — not a current product or release

The following verification report is retained as historical experiment metadata from an
older revision. Its claimed model payload is absent from the current checkout; the matching
model cards now say `not_released`. Do not treat the old serving captures, gate verdicts,
metrics, digests or artifact identifiers as evidence of a current model release or of the
active Klyvaron processor. The current processor is deterministic and model-independent.

The historical run report describes a from-scratch `aetheris-lite-lm@0.1.1` experiment and
records text-completion-only routing, a refused unpinned chat request, and install/rollback
checks. Its metadata remains available in
[`experiments/lm-verification-run-8d9cdf8.json`](./experiments/lm-verification-run-8d9cdf8.json)
for audit context only. No model payload is distributed or loaded by the active Klyvaron path.

#### What was tried, in order, before accepting this

The gap is a missing binary and missing weights, so it was attacked directly
rather than assumed. Each attempt is recorded with its result, because "no model
could be obtained" is only an honest statement alongside the evidence for it.

| Attempt | Result |
|---|---|
| `release-assets.githubusercontent.com` (llama2.c prebuilt binaries) | HTTP **000**, host unreachable |
| `gh api repos/karpathy/llama2.c/releases` | **0** releases |
| `pip install llama-cpp-python` | 0.3.36 publishes **no manylinux x86_64 wheel** for any version — source build needs a compiler toolchain and time not available here |
| `pypi.org/pypi/{tinyllama,llama-models,model2vec,llm-gguf}` | reachable, but no weights: largest is 6.6 MB of Python, and `tinyllama` only wraps a PyTorch training utility |
| `command -v ollama llama-cli llama-server llamafile mlx_lm` | all absent |
| `find / -xdev -name '*.gguf' -o -name '*.safetensors'` | files as **.safetensors or .gguf: none** on the host |
| `download.pytorch.org`, `huggingface.co` | unreachable from this sandbox |

A local model is still the goal, and the code path is ready for one — but no
reachable source in this environment provides a runtime or weights. The correct
status for **Phase 4 is "Implemented but not fully tested"**, and it is recorded
that way in §2 rather than being upgraded by the loopback fixture.

---

The ten phases of the *Klyvaron adaptive intelligence* directive are a separate programme with its
own acceptance criteria and records: [25 — Adaptive intelligence](25-adaptive-intelligence.md).
Phases 9 and 10 of that programme are summarised in §4 below.

## 3. Acceptance criteria

| Criterion | Status | Evidence |
|---|---|---|
| Five areas work in one app | **Met** | `apps/web`; `structure.test.mjs` fails if a sixth appears |
| Local chat inference with an installed model | **Not a requirement (online-first)** | Retained legacy path is tested against a loopback server; the active product performs no local inference. The 2026-10-17 override makes cloud inference the default |
| Strict offline mode verifiably blocks network | **Superseded — not a completion criterion** | The 2026-10-17 online-first override removes offline operation as a product requirement; the recording-`fetch` measurement is kept as history of the legacy path, not as a gate |
| Hybrid sends only authorized requests externally | **Met** | Exact-host allowlist + classification ceiling; `confidential`/`restricted` need explicit authorization |
| An external provider, when one is configured, uses supported endpoints and handles provider failure | **Met against fixtures; no live provider called** | The online entry saves provider connections, requires explicit consent per revision, refuses a mismatched route, and normalises auth/quota/outage failures. Twenty-two wires are contract-tested — seven chat protocols (OpenAI-compatible, Anthropic, Gemini, Cohere, Azure OpenAI, Vertex AI and Bedrock) plus ten image and five video adapters — including their differing credential chains; a valid key and quota remain unverified |
| Private knowledge indexed / retrieved / cited / managed locally | **Met** | Ingest, content-hash dedupe, chunk, BM25, cited grounding, ACL, purge, audit |
| Plugin + MCP enforce capability permissions | **Met** | Scope allowlist, elevated-scope approvals, forbidden scopes, risk-tier gates, schema validation of arguments and output |
| God Mode tasks observable / pausable / resumable / cancellable / verifiable | **Met** | All five exercised by tests; pause→resume checkpoints at `phaseIndex=1` (2 → 9 steps) |
| Image + video use real adapters when advertised | **Met** | Magic-byte validation; `assertGenuineVideo` rejects a still image and sub-8 KB payloads; refusal carries an explicit limitation |
| Sparsiz integration has a defined responsibility + reproducible tests | **Met** | [`02-architecture.md`](./02-architecture.md) §2; taxonomy/formula adopted, scoring replaced |
| ≥1 first-party Aetheris Lite model with versioned reproducible eval | **Met** | `aetheris-lite-retriever@0.1.0`; [model card](./model-cards/aetheris-lite-retriever-0.1.0.md) + machine-readable JSON |
| Benchmark comparisons identify exact models / configs / hardware / procedures | **Met for what was comparable** | [`06-benchmarks.md`](./06-benchmarks.md); every row records corpus, split, seeds, hardware and reproduction command |
| Unvalidated weights cannot silently replace stable releases | **Met** | `ModelReleaseManager.release()` validates first; a 3-epoch run yields MRR 0.3045 < 0.60 floor → `release` fails, run status `failed`, `released is null` |
| Docs match implementation | **Met** | Route table, env vars, licence texts and benchmark numbers were re-derived from source and re-measured, not transcribed from memory |

---

## 4. Component status

### `services/core` — Current test inventory (1085 tests) — full Core suite passed 1,081/1,085 locally; four genuine legacy-artifact acceptance cases skipped because fixtures are not installed. CI checks are recorded in [36 — Final engineering report](36-final-engineering-report.md).

| Subsystem | Status | Notes |
|---|---|---|
| Egress policy & guard | **Implemented and tested** | Three policies; fails safe to `strict_offline` on a blank/invalid value |
| Data classification & redaction | **Implemented and tested** | Whole-identifier patterns catch `AWS_SECRET_ACCESS_KEY`-style names |
| Audit ledger | **Implemented and tested** | Append-only SQLite; refusals audited; NDJSON export; subject purge |
| Accounts & sign-in (online entry) | **Implemented and tested** | 24 tests; scrypt hashes with no reversible copy, per-account lockout and throttling, owner/member roles, host-delivered reset codes, per-account stores; see doc 20 |
| Model registry & router | **Implemented and tested** | Capability gating before scoring; unknown latency scores 0.5, not 0 |
| Native provider adapters | **Implemented and tested against local fixtures; no live call** | Twenty-one wires. Chat: OpenAI-compatible, Anthropic Messages, Gemini generateContent, Cohere Chat v2, Azure OpenAI v1, Vertex AI and Bedrock Converse. Image: OpenAI Images, Gemini Images, Stability AI, Recraft, Ideogram, Black Forest Labs, fal.ai, Replicate and Adobe Firefly. Video: Veo, Runway, Luma, fal.ai and Replicate. Cohere paginates discovery; Azure uses `api-key` and the deployment name; Vertex exchanges a service-account JWT for a cached OAuth token; Bedrock signs with SigV4 against AWS's published vector and is non-streaming by contract; Firefly exchanges a two-part client credential for a cached IMS token. Structured credentials are validated and compacted at save time. See [docs/27](27-provider-framework.md) §4.1 and §5 |
| Ollama / llama.cpp, legacy entry | **Implemented and tested against a fixture server** | `providers/local.mjs`, used by the retained legacy service only. The online entry uses the `/v1` routes of the same runtimes; see [docs/19](19-online-only-phase-2.md) |
| Ollama / llama.cpp, online entry | **Implemented and tested against a loopback fixture** | Shared guarded provider transport; keyless by default; exact trusted origin required. No real runtime qualified here |
| Klyvaron development plan | **Implemented and tested** | Per-tier gates derived from the tier records, `klyvaron.mjs plan`; see [docs/11](11-klyvaron-family.md) §1.5 |
| Klyvaron CPU execution | **Implemented and tested** | Single worker, bounded incremental streaming, cancellation/deadlines, one-model residency; see doc 15 |
| Knowledge pipeline | **Implemented and tested** | Local SQLite stores with bounded BM25 refresh, ACL filtering, grounded citations, evaluation, and purge; persists on the end user's Docker volume |
| Media queue & validation | **Implemented and tested** | Progress, cancellation, timeouts, retry-after, state history; an optional state file makes a terminal job and its artifact survive a restart, and a job interrupted mid-run is recorded as `failed` with `interrupted`, never replayed as running |
| Plugin registry & manifests | **Implemented and tested** | Preflight vs invoke distinction; uninstall keeps a record |
| MCP layer & schema validator | **Implemented and tested** | Risk tiers, approval gates, output neutralisation, per-tool timeouts |
| God Core lifecycle | **Implemented and tested** | Eight phases, budgets, retries, checkpoints, verification |
| Built-in plugins & MCP server | **Implemented and tested** | 18 tests; see §5 |
| HTTP layer | **Implemented and tested** | 31 literal routes + segment routes; accurate error statuses |
| Adaptive core: intent, planning, capability registry, budgets, timeouts, checkpoints, resumable tasks | **Implemented and tested** | `intent.mjs` (requirements with the phrase that produced each; unmatched requests get a question), `registry.mjs`, `plan.mjs` (refuses an over-long plan or an uninstalled capability by name), `budget.mjs` (refuses to start work its measurement cannot cover; unreported token counts stay unreported), `checkpoint.mjs` (atomic, digest-chained, refuses a resume against a different plan) and `runner.mjs` (step-by-step with a checkpoint after each, resumable in a fresh object from the checkpoint alone). Exercised by tests; no route calls it yet. See [docs/25](25-adaptive-intelligence.md) §4 |
| Adaptive routing, verification, experience & skills | **Implemented and tested, one capability end to end** | The Phase 2 loop: route on measured cost, verify against a second `implementation`, record to an append-only digest-chained episode log, propose a skill only from a verified success, promote only when every recorded check passed, reuse and re-measure. Demonstrated on counting newline bytes across a tree, with the measured crossover recorded as a limitation on the skill itself. See [docs/25](25-adaptive-intelligence.md) §4 |
| Emotional interaction states and controls | **Implemented and tested; not yet reachable from the product** | Seven states estimated from the user's own phrases, never from a model of them; every estimate reports itself as an estimate with the phrases that produced it and the other families that also matched, and can be corrected, remembered only if the user allows it, and withdrawn. Sensitive material is never read as a signal (the record keeps an offset, not the phrase), a claim about the user over time needs cited signals read with consent, and the forbidden-sentence guard refuses claimed feelings, consciousness, simulated sadness, worry, jealousy, possessiveness, guilt, dependency and invented history. Settings are validated rather than interpreted, and one switch stops the reading as well as the effect. `AdaptiveLoop.explain` renders a run with those rules; nothing in Chat uses it yet. See [docs/25](25-adaptive-intelligence.md) §4 |
| Skill evaluation, regression and permissions | **Implemented and tested; not yet reachable from the product** | `skills/evaluation.mjs` + `skills/permissions.mjs`. A candidate must run and pass every check that passed for the incumbent version; a suite that lost a check is rejected as `regression_not_run` rather than passing with fewer. Verdicts go to an append-only digest-chained log, a rejected version stays in the registry, and `promote()` refuses a version with no accepted evaluation or a different check list. A skill's permission block is the scope it runs with: a declaration wider than the runtime grant is refused rather than narrowed, a larger grant is never used, and an agent-written skill may not ask for `/`, the home directory or the network. See [docs/25](25-adaptive-intelligence.md) §4 |
| Model & provider fabric | **Implemented and tested; not yet reachable from the product** | Adapters declare their kind (`in-process`, `local`, `external`), the capability tags they serve, their limits and their notes; availability is measured by probing, never assumed. One `eligibility()` is shared by routing *and* probing, so a provider the policy forbids is never *contacted* — under `strict_offline` the external adapter's `probe` is called **0 times** while a loopback one is called once — and the module contains no network primitive at all (`fetch`, `node:http`/`net`/`tls`, `undici`), which is checked by reading it rather than by a comment. Refusals carry codes: `no_capability` (naming what is declared instead), `only_external_capability`, `provider_unavailable` (with the probe's own message), `capability_exceeds_limits` (a request too large is refused, never truncated to fit), `no_eligible_provider` (with `partial_coverage`: two adapters that between them cover a request are not combined), `preference_not_eligible` and `no_egress_guard`. Eligible adapters become validated `kind: model` descriptors — an adapter whose notes say `sampled` is not described as deterministic — and can be published into the planner's registry, so a plan is only ever built against providers that are registered *and* measured. No real provider, credential or gateway exists in this build: the external path is exercised against a stub that counts calls. `test/adaptive-providers.test.mjs` (15 tests). See [docs/25](25-adaptive-intelligence.md) §4 |
| Persistent memory fabric | **Implemented and tested; not yet reachable from the product** | Seven layers (working, episodic, semantic, preference, project, skill, failure) with `assertion` and `verification` held as **separate records** on every entry, so *the user said so* and *an independent check confirmed it* cannot be read as the same thing: a claim's confidence has no number at all. Required provenance rows, versions on correction, contradictions kept and listed, scope and readers enforced on read with each exclusion naming its reason, deletion that takes the provenance with it and leaves a content-free tombstone, and the skill/episodic/failure layers **referencing** the registry and the episode log instead of copying them. The bridge with the existing product memory goes one way each way: an approved memory enters as a claim (approval is permission, not verification) and a fabric entry leaves as a candidate a person must approve. Tested by `memory-fabric.test.mjs` (18) and `memory-bridge.test.mjs` (7). No HTTP route or panel reads it yet, and it is not a retrieval model — there is no ranking beyond SQL ordering and no embedding of any kind. See [docs/25](25-adaptive-intelligence.md) §4 |
| Plugin and MCP authority boundary | **Implemented and tested and reachable from the product** | Every tool, plugin, resource and prompt result now carries a **provenance** — origin, digest of the exact bytes, and whether the text is instruction-shaped — instead of a bare `untrusted: true`. A consequential action (write, destructive, external, system) must cite a reason, and a reason that came from data is refused (`tainted_justification`) no matter how clearly it asks: authority is minted only from a **user turn** (`not_a_user_turn`), a grant names its actions rather than `*`, the ceiling is checked against the action's risk tier, a hand-edited copy of a token is `authority_tampered` because the fields are re-digested and privileges are read from the stored record, and taint survives derivation so a model's summary of a tool output is refused for the same reason the output was. The instruction classifier is **audit evidence, not the gate**: one named test proves an instruction it does not recognise is refused identically, so a false negative costs nothing. A user turn may `endorse` acting on data, and the record names who and why while the provenance stays untrusted. `test/mcp-authority.test.mjs` (11 tests). See [docs/25](25-adaptive-intelligence.md) §4 |
| Image generation | **Implemented and tested for ten image wires; no live call** | `POST /api/image/generate` validates prompt (4,000 characters), size and model, then queues a durable per-account job (202). The selected wire posts to its provider (OpenAI `{base}/images/generations`, Gemini `{base}/models/{model}:generateContent`, Stability `/v2beta/stable-image/generate/*`, Recraft `/v1/images/generations`, Ideogram `/v2/image/generate/*`, Black Forest Labs `/v1/*`, the fal.ai queue, Replicate predictions, Adobe Firefly `/v3/images/generate*`, and local ComfyUI checkpoint workflows), decodes inline bytes, and accepts the artifact only if the container re-encodes to the same bytes; a URL-only or non-image response is `invalid_completion`. Jobs survive a restart, are owned by one account, and `GET /api/image/jobs/<id>/content` serves the stored bytes with `nosniff` and a sandbox CSP. The Image area renders only a succeeded job and shows its prompt, provider, model, size, digest and byte length. `test/online-image.test.mjs` (9 tests), `test/online-gemini-images.test.mjs` (3) and the image half of `test/online-media-wires.test.mjs`; see [docs/27](27-provider-framework.md) §5 |

| Video generation | **Implemented and tested for five video wires; no live call** | `POST /api/video/generate` validates prompt, aspect ratio, resolution and model, then queues a durable per-account job (202). The five video wires (`gemini_veo`, Runway tasks, Luma generations, fal.ai queue and Replicate predictions) poll with bounded cancellable loops, download delivery URLs as bytes (the key goes only to the configured API origin), and store the MP4 only if the container validates. Duration is measured from `moov/mvhd`; a still image or stub fails `assertGenuineVideo`. `POST /api/video/jobs/<id>/cancel` aborts the live request. `test/online-video.test.mjs` (9 tests) and the video half of `test/online-media-wires.test.mjs`; see [docs/27](27-provider-framework.md) §5 |

| Reviewed procedures | **Implemented and tested** | Owner installs a structured document; a named structural review (document parses, at least two steps, scope declared, no network) promotes a candidate, and a new version is a candidate again. A validated, text-only procedure can be selected for one message: its text is sent as reference material, usage is counted only after the provider answers, and versions, rollback and deletion persist. A procedure declaring file or network access is refused because this product has no executor. `test/online-skills.test.mjs` (9 tests); the learned-procedure surface stays archived |

| Response styles | **Implemented and tested** | Seven styles (supportive, focused, curious, cautious, reflective, playful, technical), set by the person in Chat and stored per account. The server sends the style as an instruction with the prohibitions attached, audits every reply, shows soft findings without rewriting the text, and refuses a claim of consciousness, dependence or manipulation with `style_violation`, storing nothing. Nothing infers a style from a message: the estimator stays a library. `test/online-styles.test.mjs` (8 tests) |

| Measured procedure comparison | **Implemented and tested** | The owner can measure two versions on up to five cases through the active chat connection, with explicit consent and a listed model. Each case is scored deterministically against phrases it must and must not contain; a regression is checked before the aggregate, equal scores are reported as no measured difference, and the record stores measurements and prompt digests, never prompt text. It does not promote a version. `test/online-skill-measure.test.mjs` (6 tests) |
| Video workflow | **Implemented and tested; no provider installed** | Same module: a video request needs a real clip — a still image returned instead is refused as `still_image_substitution`, a stub under 8 KiB as `output_too_small`, and a clip shorter than requested as `duration_short`. Duration is read from the MP4 `mvhd` box; a WebM returns `verified: partial` naming the unparsed EBML duration rather than assuming it. The legacy route still refuses with `needs_hardware` (501); **never substitutes a still image**, and this workflow is the check that would catch it if it tried. See [docs/25](25-adaptive-intelligence.md) §4 |

### `services/fabric` — Implemented and tested (823 tests)

| Stage | Status |
|---|---|
| data_validation | **Implemented and tested** |
| base_selection | **Implemented and tested** — compares candidate widths by held-out MRR; a language-model base is *not* selected ("no weights available on this host") |
| domain_training | **Implemented and tested** — hand-written Adam; all 5 parameter gradients match central finite differences to ~3e-10 |
| sft | **Blocked — requires weights** |
| preference_optimization | **Blocked — requires weights, data and a reward signal** |
| distillation | **Implemented and tested** — logit distillation from a locally trained teacher runs here with no credentials; distillation from an *external* teacher is **Requires external credentials** (built and tested against a local fixture, never run against a provider). See [`09-distillation.md`](./09-distillation.md) |
| evaluation | **Implemented and tested** |
| release | **Implemented and tested** — validates before releasing; rollback restores a prior version |

Overall run status is therefore **`partial`**, never `completed`. Supporting
pieces all tested: failure taxonomy, failure memory (`E_{t+1} = E_t ∪ F_t`),
experiment ledger (baseline → experiment → verdict), metrics with a latency noise
floor, DataForge, the Node↔Python text-parity fixture, model cards, and the HTTP
server (23 tests).

The separate real Hugging Face + PEFT LoRA smoke path is built but **not run**. It no
longer requires a notebook or GPU: `services/fabric/remote/run_smoke_local.py` installs
the reviewed optional stack, uses CUDA when available and CPU otherwise, and keeps its
checkpoints and `status.json` under an explicit work directory. This sandbox still cannot
reach the model hub, so that implementation does not turn NOT RUN into a result; the first
external run remains the evidence needed. See [docs/21](./21-remote-training.md).

**Cross-task transfer (L4) is implemented and was run as a pre-registered
experiment.** `fabric/transfer.py` holds the protocol — five fusion strategies, one
a-priori baseline, a one-metric decision rule, a family split decided in advance —
and `scripts/l4_transfer.py` produces the measurements; `tests/test_transfer.py` (27
tests) pins the decision procedure, including the cases where it must *refuse* a
conclusion. The recorded run is a **null**: over eight seeds the a-priori baseline
was the best strategy on the selection family, so no lesson qualified for transfer,
and the held-out families are recorded as observations rather than as a transfer.
Numbers: [`06-benchmarks.md`](./06-benchmarks.md) §9, narrative:
[`07-improvement-cycle.md`](./07-improvement-cycle.md) §9, raw cells:
[`experiments/l4-transfer.json`](./experiments/l4-transfer.json).

`fabric/lm/` is the one part of this service that does **not** follow the
`base_selection → domain_training → sft` path, because it does not need a base to
select from. It trains a character-level language model from random initialisation
using corpora it already has, which is why it is not blocked where the retrieval
pipeline is. See [`08-aetheris-lite.md`](./08-aetheris-lite.md). It carries the
same discipline: a corpus split that cannot leak, held-out evaluation against
computed baselines, a versioned card, and a gate that refuses.

Two limits on that statement are worth stating plainly rather than implying. The
corpus is this repository's own text, so **every commit changes the corpus and
therefore the model**; the first attempt at a reproduction produced a different
model (first loss 4.8057 against the release's 4.8380) and the first attempt at the
distillation experiment was refused outright when eight characters entered the
corpus. A run now writes its exact corpus beside its weights, and a reproduction can
be demanded or refused by digest rather than assumed. The full release configuration
was then run twice more, end to end. The first, on the tree at `67cdd58`: 2,005 s of
training, a corpus manifest of its own, a model of 359,520 parameters, and a gate verdict of
**RELEASED** (perplexity 5.3585 against the bigram's 16.7151, 0 hard failures). That run's
corpus turned out to include this project's own build products — `artifacts/` was missing
from the directories discovery skips — so it was fixed and the configuration re-run on the
tree at `8d9cdf8`, whose corpus rebuilds byte for byte from the commit: **that artifact is
the released `aetheris-lite-lm@0.1.1`** (359,616 parameters, perplexity 4.8932 against the
bigram's 15.7588, ratio 0.310505, gate verdict RELEASED, 0 hard and 0 soft failures). The
superseded `@0.1.0` (359,136 parameters) stays published with its own card; none of the
three perplexities is comparable with another, because the same token budget went into
corpora of different sizes, and none is reported as an improvement. That
artifact was then installed into a core data directory through `KlyvaronStore.install`,
loaded by the app, and served over HTTP: `/api/ready` reports `textCompletion: true`
and `chat: false`, an unpinned `/api/chat` is refused with `model_not_instruction_tuned`
(501), a pinned one returns a labelled continuation, and the streaming path emits
`route`/`delta`/`done` events. Python and JavaScript produce the same greedy text from
the same bytes (max logit difference 8.2e-06). Record:
[`experiments/lm-verification-run-67cdd58.json`](./experiments/lm-verification-run-67cdd58.json).
### What the CI check found, and why it took a diagnostic to see it

The **Fabric** job was red on this branch from the first Klyvaron Lite commit while every
local run of the same suite was green — a clean venv, a pristine clone, depth-1 and full
history, the same NumPy and pytest. The reason could not be read the usual way: a job log is
served from a host an agent without the repository's browser session cannot reach, and the
log page itself is behind a sign-in wall. The test step now emits the failing test and its
assertion as a check annotation, which the checks API serves openly, and the answer arrived
in one line: the committed cross-language parity fixture regenerated *byte for byte
differently* on the runner while all fourteen arrays were identical. CPython 3.11.2 frames
each local record with version-needed 20 beside the real sizes; 3.11.17 writes 45 with both
sizes replaced by the `0xffffffff` sentinel that ZIP64 defines for "the value is in the extra
field". Same members, same weights, a different container — the fixture test was comparing a
container built by the standard library.

Two things changed, both in the honest direction. The fixture test now compares the *model*
(tokenizer digest, member names, per-array dtype, shape and values) and reports which array
changed and by how much when it fails; the container is the standard library's, not this
project's. And the JavaScript reader resolves ZIP64 sentinels instead of trusting the fixed
fields, because an artifact is bytes and the interpreter that wrote it is not recorded in
them — `klyvaron-runtime.test.mjs` reads the committed fixture reframed both ways and asserts
the weights are identical, and asserts a refusal (not a guess) when a sentinel cannot be
resolved anywhere. Both tests fail against the previous reader.

And the model emits mush at this size — 359,616 parameters is enough to beat every
baseline it was measured against and not enough to hold a conversation.

### `apps/web` — Implemented and tested (143 tests)

| Area | Status |
|---|---|
| Chat | **Platform parity partial** — streaming SSE, stored catalogue capability evidence, provider-gated text/document/media attachments with explicit Send, knowledge ingest/search/citations, task lifecycle, resumable conversations with continuation disclosure, browser-local projects/custom titles/session pins, manual consent-gated MCP calls, local-only transcript tools (in-transcript search/filter, message pins, Markdown export, keyboard shortcuts, opt-in client-side JSON syntax validation and catalogue context-limit reporting), provider fabric evidence, and a Phase 3–9 local orchestration panel with plan preview and bounded deterministic execution. Transcript tools, provider fabric and orchestration are implemented and contract-tested, not live-verified; provider-native search/tool calling, model inference, sandboxes, deployments and release publication remain refused or blocked. |
| Image | **Implemented** — job queue, validation display; generation refuses on this host |
| Video | **Implemented** — as above, plus the genuineness rule |
| Plugins | **Implemented and tested** — manifest validation, install, preflight, invoke, approvals |
| MCP | **Implemented and tested** — servers, tools, risk gates, elevated-scope approvals |

**Rendering is covered** by `test/render.test.mjs` (43 tests), added after an
earlier revision of this document recorded the rendering layer as "implemented, not
fully tested". There is no browser here, and adding `jsdom` would have meant a new
dependency tree — so instead the test bundles the JSX with `rolldown` (already a Vite 8
dependency) and renders it with `react-dom/server` (already a `react-dom`
dependency). **No new dependency**, and no DOM required. `renderToStaticMarkup`
does not run effects, so nothing hits the network: every component is rendered in
its pre-fetch state, which is what a user sees first and the state most likely to
crash on a missing field.

What it covers: all five areas in three states each (degraded readiness, ready
readiness, and `null` — the actual first-paint value); `App` and the shell;
`StatusCard` in all three of its branches; all sixteen shared UI primitives with
their real prop signatures; fixture labelling; that the policy is never rendered as
an input; and that MCP's empty state does not invent servers or tools. Since sign-in
became accounts, it also renders all three sign-in pages, both steps of the reset page
(the second is only reachable after a state change, so it is exported and rendered on
its own), and the change-password dialog in the sidebar.

**Writing this test found a real bug that nothing else had caught.** `Shell.jsx`
contained

```js
export { AREAS, AREA_IDS } from '../areas.js'
```

and then called `AREAS.map(...)` in the navigation. A re-export forwards a binding
to *importers*; it does not create one in the module's own scope. So the shell
threw `AREAS is not defined` on render — **the entire interface was broken**, and
it had been since `AREAS` moved out of `Shell.jsx` into `areas.js`. Fixed by
importing the list as well as re-exporting it.

This is worth recording precisely because of what did *not* catch it. All fourteen
modules transformed and served HTTP 200 through the dev server; `/` returned 200;
the production build succeeded with no warnings; and 39 tests passed. Every one of
those checks is about *compilation*, and the defect was at *runtime*. A module can
be perfectly valid JavaScript and still throw the first time React renders it. The
"modules return 200" verification recorded in an earlier revision of this document
was real but was not evidence that the app rendered, and it should not have been
treated as near-enough.

### 4.1 A flake in the fabric resume test, found by CI and fixed at the cause

`services/fabric/tests/test_lm_train.py::test_a_resumed_run_is_the_same_run_it_would_have_been`
failed once in CI on 2026-10-16 with `{'checkpoint': 'r-….ckpt.npz', 'step': 6} == {…, 'step': 5}`,
while passing locally and passing in every other CI run. It is the one test where two processes touch
one file: it kills a child mid-run and resumes from the checkpoint that child left behind. The test
validated the checkpoint in place and *then* copied it, and the child saved the next checkpoint
between those two calls — so the bytes that were copied came from step 6 while the metadata being
compared against came from step 5. **The mechanism is confirmed rather than inferred:** with a
deliberate 40 ms gap between the read and the copy, 3 of 3 trials copied a different step than they
read (`(3, 6) (4, 7) (2, 5)`); copying first and reading the copy agreed in 3 of 3. The fix is that
ordering. The assertion is unchanged — the test was right about the run and wrong about which file it
was holding, and the checkpoint file itself is written to a staging name and moved into place, so a
reader never sees a half-written one.

### 4.2 A docs check that could not fail, found while writing the Phase 6 record

`README.md` stated **709 / 1615** tests in its setup snippet and in its "run in CI" line while its own
component table, two sections below, said **738** — and `docs.test.mjs` asserted the *stale* form
(`README must state the same totals`), so the contradiction passed every check in CI for two phases.
The status document was checked against the filesystem and the README was checked against a literal,
which is how the same figure was right in one file and wrong in the other. The test now requires
README and `docs/03` to state the same total, requires the "run in CI" line to carry it too, and
refuses every superseded form in both documents. A number stated twice with one test guarding one copy
is a number nobody is guarding.

### 4.3 Repository hygiene: what was deleted, what was merged, and what was kept

A full inventory of the 322 tracked files, done 2026-10-17. The test for "unwanted" was evidence,
not taste: a file is dead if nothing imports it, nothing tests it, and no documented procedure runs
it. Three things qualified.

**Deleted: `apps/web/legacy/` (8 files, ~230 KB).** Eight superseded React components — a second
`ChatArea`, `Shell`, `ImageArea` and so on — that no module imported, no test loaded, and the Vite
build never reached. Every one has a current replacement in `apps/web/src/areas/` and
`apps/web/src/components/`. They were kept in the Phase 2 change as "prior UI references"; a
reference nothing reads is not a reference, it is a copy that will drift. `docs/19` said they were
preserved, so `docs/19` was corrected rather than the deletion being left to contradict it.

**Merged: `withTimeout`, from two files into one.** `mcp/layer.mjs` and `plugins/registry.mjs` each
had their own copy of the same race — a timer, an abort listener and a cleared timeout — differing
only in which error class they rejected with. It now lives in `src/shared/timeout.mjs` and each
caller passes the errors it needs, because the *type* of a failure is part of a caller's contract
and the *mechanism* is not. Two copies of a timeout are two places for a cancellation to be lost.
The shared version also fixes what the copies had in common: the work is a thunk (an already-running
promise cannot be cancelled, and the clock now starts where the work does) and the caller's timer is
cleared on every path.

**Kept, and why:**

| File | Verdict |
|---|---|
| `services/core/src/legacy-server.mjs` (153) | Nothing imports it, but it is a documented entry point (`docs/02`, `docs/04`) over `app.mjs`, which `builtins.test.mjs` does exercise. Removing an entry point is a product decision, not hygiene |
| `third-party/licenses/aetheris-MIT.txt` | Byte-identical to `LICENSE`, but it is the record of the *upstream* repository's licence and is asserted by `docs.test.mjs` and by CI. The duplicate is the point: a licence record has to travel with the code it covers |
| `docs/experiments/*.json` (15) and `phase1-probes.mjs` | Measurement records with dates and machine details. Deleting one deletes the evidence for a claim in the docs |
| `services/fabric/remote/*` | The notebook, its job spec and the local runner are exercised by `test_training_notebook.py` and `test_training_local_runner.py` |
| `apps/web/src/components/ContextPanels.jsx` | One direct importer, but that importer is the Chat panel that renders it, and two web tests assert its contents |

No untracked or ignored artefacts were found in the tree beyond the empty, gitignored
`.aetheris-data/`. The suite after the change: **831 / 831** core, 48/48 docs, 93/93 web (run with
`npm ci`), 814 fabric.

**Repository cleanup (2026-11-01):** removed `apps/web/src/components/Jobs.jsx` and its
empty-table-only render test because Image and Video render their own job surfaces. At that point, after the user selected Docker-only deployment, the unused Vercel functions/configuration,
Supabase adapters, migrations, their integration tests, and hosted-deployment smoke material were removed.
No test fixtures, model evidence, licences, or external hosted data were deleted; external
projects, deployments, settings, accounts, and data were not accessed or changed. The later hosted BYOK increment reintroduces a distinct opt-in hosted deployment; Docker Compose remains the default local path.

### Phases 9–10 — industry packs, and a release that verifies its own numbers

Two increments, both additive: no existing module changed API, and the product routes are untouched.

| Module | Lines | What it establishes |
|---|---|---|
| `packs/manifest.mjs` | 249 | A pack is content and restriction: unknown keys refused, `dataClassFloor` can only rise, a regulated pack must require human review and name a refusal, and every capability carries either the file that evidences it or `unimplemented: true` |
| `packs/registry.mjs` | 277 | Install/enable/disable/uninstall with history and no downgrade by accident; readiness measured against the provider fabric in four states (`unknown`, `unavailable`, `partial`, `complete`); `profileFor` refuses an unavailable pack unless the gap is acknowledged; **no method grants, authorises or executes** |
| `packs/builtin.mjs` | 131 | Three shipped packs — engineering repo maintenance, legal document review, grounded tutoring — each narrowing only |
| `benchmark/harness.mjs` | 254 | Seven benchmarks over the real modules; a failed entry is kept with its error and fails the run; a zero-duration run raises instead of reporting `0 ops/s` |
| `release/manifest.mjs` | 290 | One version across `VERSION` and three packages, a dated changelog entry, documented totals compared against *supplied* measurements, required artefacts present, pack evidence on disk |

**The benchmark found a defect before the release did.** The first `readiness()` reported a pack that
honestly declared an unimplemented capability as `partial` alongside packs whose dependencies were
genuinely missing, and `profileFor` refused both. That made disclosure more expensive than silence —
the exact incentive a project about not overclaiming cannot afford. The states were split:
`unavailable` (a dependency is not served; application refused by name) and `partial` (everything
required is served, a declared gap remains; applies normally). The fix has its own assertion.

**What the release check refuses**, each case a crafted test rather than a comment: a package on an
old version; a changelog with no entry, no date, or nothing in it; a documented total one too high; a
stale grand total; a README that drifts from `docs/03`; **two documents that agree with each other
and not with the suite**; a missing artefact; a pack citing a file that is not there.

Measured release verification on this host:

| Check | Result |
|---|---|
| `node services/core/scripts/release-check.mjs --core 944 --web 100 --fabric 821` | `release 0.2.0 verified against 944 + 100 + 821 = 1865 tests` |
| `node services/core/scripts/benchmark-adaptive.mjs` | 7/7 benchmarks, 0 failed, artefact at `docs/experiments/phase10-benchmark.json` |
| `VERSION` / three `package.json` / `package-lock.json` | all `0.2.0` |

---

## 5. Built-in plugins and the in-process MCP server

Added because the Plugins and MCP areas were otherwise unfillable: a browser
cannot bind a `local_tool` handler, so handlers must be bound in code at boot.

| Component | Capabilities | Risk / scopes |
|---|---|---|
| `aetheris.insight@1.0.0` | `system.hardware`, `system.readiness`, `audit.tail`, `media.jobs` | all read-only, **no scopes** |
| `aetheris.knowledge@1.0.0` | `knowledge.search`, `knowledge.stats`, `knowledge.documents` | read-only, `knowledge.read` (not elevated) |
| `aetheris.local` (MCP) | `aetheris.hardware`, `aetheris.knowledge.search` | `read_only` |
| | `aetheris.knowledge.ingest` | `write` + elevated `knowledge.write` |
| | `aetheris.task.cancel` | `destructive`, always needs approval |
| | resource `aetheris://status`, prompt `grounded_answer` | — |

`system` and `external` risk tiers are **deliberately absent**: `system` is
refused by this build's `allowedRisks`, and no external endpoint is configured.
Neither is stubbed to look complete, and `builtins.test.mjs` asserts their
absence.

Tested beyond "registers and returns data": every capability has a genuinely bound
handler; schemas are enforced against the built-ins themselves; granting a scope
at installation level is *not* consent to use it (an approval must name the
scope); disabling a built-in stops it being invocable; a built-in cannot be
uninstalled and the refusal is audited; **invoking every built-in capability opens
no network connection at all**; and handler output is plain serialisable data,
never a live internal reference.

Verified live over HTTP through the dev-server proxy: plugin invoke returns real
hardware data, a missing required argument yields **403 `plugin_permission_denied`**,
and an unapproved destructive MCP call yields **409 `approval_required`**.

The online product registers two in-process servers of its own: `aetheris.online`
(`connection.status`, read-only) and `installation-docs` (`list-documents` and
`read-document`, read-only, bounded to 20,000 characters, resolved from the
repository's `docs/` directory rather than the working directory). A member can
read both; only the owner can toggle a server. `test/online-mcp.test.mjs` (5
tests) checks the catalogue, preflight, argument validation, the path refusal,
the untrusted provenance label, the owner gate and the disabled-server refusal.

---

## 6. Known defects found and fixed

Recorded because the classes of bug matter more than the individual fixes.

**Core service**

- `publicView()` returned live references → deep-copied via `cloneValue()`.
- `this[\`#${phase}\`]` was always `undefined`, and a `continue` inside `for...of`
  skipped the retried phase → index-based loop.
- `resume()` sliced from `fromIndex + 1`, skipping the paused phase.
- Budget was spent inside builtin handlers, so a custom handler could bypass it →
  moved to `#accountPhase` in the run loop.
- Domain errors fell through to **HTTP 500**, making a policy refusal
  indistinguishable from a crash → `ERROR_STATUS`/`statusForError`.
- **Capability refusals were not audited** — the most security-relevant events were
  the ones missing → `#refuse()`.
- The secret classifier missed env-var-style credentials, so such a prompt
  classified `public` and could have left the machine in hybrid mode.
- **`online_enabled` could not actually go online.** The policy relaxed the
  data-classification gate, but the egress guard still consulted the allowlist, so
  with an empty allowlist it rejected every external host and enforced exactly what
  `strict_offline` did. A policy named "online enabled" that cannot reach anything
  online is a control whose name promises more than it delivers — and the failure
  was silent, since nothing distinguished "blocked because offline" from "blocked
  because no host was listed". → the `*` sentinel, checked *after* `strict_offline`;
  a distinct loader warning when `*` is combined with `online_enabled`, which
  bypasses classification; and `allowAllExternal` in `publicConfig` so wide-open
  egress is visible in `/api/config` rather than only in an env file.

Lesson recorded: `node --check` catches neither private-member misuse nor
control-flow errors. Always instantiate and exercise.

**Fabric**

- `math.sqrt` applied to a NumPy array in the Adam step.
- The backward pass concatenated *embedding matrices* along axis 1 instead of
  building the `[B, B+1]` logit matrix — hard negatives are a rowwise dot product,
  not shared candidates. All five gradients now verified against finite differences.
- `RecordMixin(dict)` mixed into a `@dataclass` made attribute-only records
  **falsy**, so `if card.provenance` was always False and provenance serialised to
  `null`.
- `base_selection` recorded the baseline before measuring latency, then mutated the
  frozen baseline.
- `MetricSpec.improved` accepted a *flat* result as an improvement.

**Fabric HTTP server** (found by `tests/test_server.py`)

- `/models/current` was registered under `do_POST`, so reading a release 404'd.
- Refusing an oversized body without consuming it left the client writing →
  `Broken pipe` instead of a clean 413.

**Benchmark design — two rounds of self-correction**

1. The first dataset gave BM25 **exactly 0.0 on every metric**: a rigged comparison
   proving nothing. Fixed by labelling half the queries with a topic word →
   BM25 MRR 0.335 (low overlap) / 0.767 (high).
2. The held-out set was always query index 0, which is always the labelled
   phrasing — systematically favouring BM25. Fixed with per-topic random selection,
   recording `evaluationLabelledFraction` in `meta`.
3. A 5% relative latency tolerance rejected the dense retriever because 0.0216 ms
   vs 0.0549 ms is a difference smaller than a scheduler quantum. Fixed with a
   1.0 ms noise floor, documented, with the absolute ceiling on the model card.

**Web app**

- The artifact URL was written as `/api/media/:id`; the real route is
  `/api/media/artifact/:id`. Caught by reading the router rather than by a browser.
- `/api/media/jobs` does not filter by `kind` server-side, so sending a `kind`
  parameter implied filtering that does not happen. Removed.
- The lifecycle renderer checked for step status `'completed'`; the real value is
  `'complete'`, which would have shown every finished phase as idle.
- **`Shell.jsx` re-exported `AREAS` without importing it**, so the navigation's
  `AREAS.map(...)` threw `AREAS is not defined` and the whole interface was broken.
  A re-export forwards a binding to importers; it does not create one locally. Found
  only by the render test — every module compiled, served 200 and built cleanly,
  because those are compile-time checks and this was a runtime defect. See §4.
- The MCP console exposed `grantedScopes` but not the **separate** elevated-scope
  approval, so an ingest call could never have succeeded from the UI.

---

## 7. What remains

Ordered by how much it blocks the acceptance criteria.

1. **Install a real local LM** (Phase 4). `ollama pull <model>` on a host with
   network access to a registry, then re-probe. No code change is expected — that
   is the claim the loopback test supports, and it is the single largest gap
   between this repository and a usable product.
2. **Add an external provider, or keep refusing** (Phase 6 gave the decision an
   executable form). The online integration was removed rather than configured:
   there is still no provider, no credential and no allowlisted gateway in this
   build. What is new is that the *rules* for adding one are code rather than
   intent: an external adapter cannot even be registered with `privacy:
   'local-only'`, it is ineligible whenever no egress guard is installed and under
   `strict_offline` it is never contacted, and it is only probed when the caller
   opts in. So the remaining work is genuinely the decision and its credentials,
   not the plumbing — and until it is taken, image and video requests are refused
   with an explicit limitation, and the readiness view reports those capabilities
   as unavailable.
3. **Run the pipeline against a real corpus.** The fixture corpus is generated
   engineering documentation; retrieval quality on real company documents is
   unknown and is recorded as a limitation on the model card.
4. **Build a failure corpus** so `historicalFailures` can be measured. It is
   currently the one soft failure on the release card.
5. ~~**Component-level UI tests.**~~ **Done** — `apps/web/test/render.test.mjs`
   server-renders all five areas, the shell, the status card and every shared
   primitive using `rolldown` and `react-dom/server`, both already installed, so no
   DOM or new dependency was needed. It found the `AREAS` re-export defect (§4).
   What is still absent is *interaction* testing: nothing clicks a button, submits
   a form or follows an effect-driven fetch, because that needs a DOM. The initial
   render path is covered; the post-interaction paths are not.
6. **SFT / preference optimization / distillation** (Phase 10). All three need
   weights and, for the first and third, a GPU. Not achievable on this host and
   not faked.
7. **Connect a verified procedure to a running task** (L3) — **narrowed 2026-10-16.** The step
   that offers a stored procedure to a task while it runs, and the step that proposes one from
   a recorded success without being asked, both exist now in the adaptive loop and carry the
   milestone test ([docs/25](25-adaptive-intelligence.md) §4). What is still absent is the
   product surface: no HTTP route and no Chat panel runs the loop, so in the running product a
   procedure is still something a person loads deliberately. The demonstration is also one
   capability wide — counting newline bytes across a tree — and its measured crossover is
   recorded on the skill, so nothing here implies the assistant teaches itself in general.
8. **Select a strategy from experience while serving** (L4). The transfer test is
   implemented and has been run, and its result was a null: nothing beat the a-priori
   fusion weights, so there is nothing to select. The gap that remains is the plumbing
   — no component chooses a strategy at request time from what past tasks showed —
   and it is a gap that the measurement says should not be closed by tuning this
   fixture.
9. **A competitive benchmark against named open models** (Phase 11). Requires
   downloads that are blocked here. Until it exists, **no superiority claim over
   Mistral, Qwen, Llama, Gemma or DeepSeek is made or implied anywhere in this
   repository.**
